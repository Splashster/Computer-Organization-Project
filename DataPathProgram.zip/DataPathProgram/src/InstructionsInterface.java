public interface InstructionsInterface{
	

	public void AddTwoOperands(String destinationName,String source1Name, String source2Name,String source1,String source2);
	public void AddOneOperandMem(String destination, String source,String memRef);
	public void AndTwoOperands(String destinationName,String source1Name, String source2Name,String source1,String source2);
	public void AddOneOperandsrc1Imm(String destinationName,String source2Name, String source2,int immediate);
	public void AddOneOperandsrc2Imm(String destinationName,String source1Name,String source1,int immediate);
    //public int AddTwoOperands(String source1, String source2);

	public void StoreTwoOperands(String destination, String source); 

	public void Call(String destination);

	public void LoadTwoOperands(String destination, String source);

	public void AndOneOperandImm(String destination,String source1,int immediate);
}