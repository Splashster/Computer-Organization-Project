public class And{
	public And(){}
}
