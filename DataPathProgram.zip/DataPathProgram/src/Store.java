public class Store{
	public Store(){}
}
