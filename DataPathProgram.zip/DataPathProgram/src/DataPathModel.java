import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLayeredPane;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

import java.awt.Color;

import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.AbstractAction;

import java.awt.event.ActionEvent;
import java.util.Random;

import javax.swing.Action;
import javax.swing.JTextPane;

import java.awt.Button;
import java.awt.event.ActionListener;

import javax.swing.SwingConstants;

import java.awt.Font;


public class DataPathModel implements InstructionsInterface{
	private JFrame frame;
	protected String source1,source2,immediate,destination,memoryReference,src1Address
	,src2Address,destAddress,address,bSelect,cSelect,ySelect,computation,source1Name,source2Name,destinationName;
	protected int sourceAddress1, sourceAddress2,destinationAddress;
	private JLabel addressBLabel;
	private final Action action = new SwingAction();
	private JLabel addressCLabel;
	private JLabel cSelectLabel;
	private JLabel registerCLabel;
	private JLabel registerALabel;
	private JLabel registerBLabel;
	private JLabel registerRALabel;
	private JLabel registerRBLabel;
	private JLabel rf_WriteLabel;
	private JLabel bSelectLabel;
	private JButton nextStageButton;
	private JLabel immediateLabel;
	private JLabel aluInputA;
	private JLabel aluInputB;
	private JLabel aluOutput;
	private JLabel registerRZLabel;
	private JLabel registerRMLabel;
	private JLabel memoryAccessLabel;
	private JLabel memoryDataLabel;
	private JLabel returnAddressLabel;
	private JLabel registerRYLabel;
	private JLabel ySelectLabel;
	private Random ran = new Random();
	private JLabel addressALabel;
	private JLabel lblNewLabel;
	private int count = 1;
	private Button resetButton;
	private int result = 0;

	final String hexNum = "0123456789ABCDEF";
    final int hexCount = hexNum.length();
	
	public DataPathModel() {
		initialize();
	}


	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 695, 1010);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		frame.setLocation(dim.width/2-frame.getSize().width/2, dim.height/2-frame.getSize().height/2);
		JLayeredPane layeredPane = new JLayeredPane();
		GroupLayout groupLayout = new GroupLayout(frame.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addComponent(layeredPane, GroupLayout.DEFAULT_SIZE, 695, Short.MAX_VALUE)
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addComponent(layeredPane, GroupLayout.DEFAULT_SIZE, 1010, Short.MAX_VALUE)
		);
		
		addressBLabel = new JLabel();
		addressBLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		addressBLabel.setHorizontalAlignment(SwingConstants.CENTER);
		addressBLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		addressBLabel.setOpaque(true);
		addressBLabel.setBackground(Color.WHITE);
		addressBLabel.setBounds(150, 138, 81, 20);
		layeredPane.add(addressBLabel);
		
		nextStageButton = new JButton("Next Stage");
		nextStageButton.setAction(action);
		nextStageButton.setBackground(Color.LIGHT_GRAY);
		nextStageButton.setBounds(588, 951, 99, 32);
		layeredPane.add(nextStageButton);
		
		
		rf_WriteLabel = new JLabel("");
		rf_WriteLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		rf_WriteLabel.setHorizontalAlignment(SwingConstants.CENTER);
		rf_WriteLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		rf_WriteLabel.setOpaque(true);
		rf_WriteLabel.setBackground(Color.WHITE);
		rf_WriteLabel.setBounds(370, 11, 83, 31);
		layeredPane.add(rf_WriteLabel);
		JLabel datapathPicture = new JLabel();
		datapathPicture.setHorizontalTextPosition(SwingConstants.CENTER);
		datapathPicture.setHorizontalAlignment(SwingConstants.CENTER);
		datapathPicture.setBackground(Color.WHITE);
		Image img = new ImageIcon(this.getClass().getResource("Datapath.jpg")).getImage();
		
		addressCLabel = new JLabel("");
		addressCLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		addressCLabel.setOpaque(true);
		addressCLabel.setBackground(Color.WHITE);
		addressCLabel.setBounds(388, 152, 81, 28);
		layeredPane.add(addressCLabel);
		
		cSelectLabel = new JLabel("");
		cSelectLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		cSelectLabel.setHorizontalAlignment(SwingConstants.CENTER);
		cSelectLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		cSelectLabel.setBackground(Color.WHITE);
		cSelectLabel.setForeground(Color.BLACK);
		cSelectLabel.setOpaque(true);
		cSelectLabel.setBounds(569, 186, 66, 32);
		layeredPane.add(cSelectLabel);
		
		registerCLabel = new JLabel("");
		registerCLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		registerCLabel.setHorizontalAlignment(SwingConstants.CENTER);
		registerCLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		registerCLabel.setBackground(Color.WHITE);
		registerCLabel.setOpaque(true);
		registerCLabel.setBounds(248, 52, 110, 32);
		layeredPane.add(registerCLabel);
		
		registerALabel = new JLabel("");
		registerALabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		registerALabel.setHorizontalAlignment(SwingConstants.CENTER);
		registerALabel.setHorizontalTextPosition(SwingConstants.CENTER);
		registerALabel.setOpaque(true);
		registerALabel.setBackground(Color.WHITE);
		registerALabel.setBounds(248, 175, 52, 32);
		layeredPane.add(registerALabel);
		
		registerBLabel = new JLabel("");
		registerBLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		registerBLabel.setHorizontalAlignment(SwingConstants.CENTER);
		registerBLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		registerBLabel.setBackground(Color.WHITE);
		registerBLabel.setOpaque(true);
		registerBLabel.setBounds(306, 175, 52, 32);
		layeredPane.add(registerBLabel);
		
		registerRALabel = new JLabel("");
		registerRALabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		registerRALabel.setHorizontalAlignment(SwingConstants.CENTER);
		registerRALabel.setHorizontalTextPosition(SwingConstants.CENTER);
		registerRALabel.setBackground(Color.WHITE);
		registerRALabel.setOpaque(true);
		registerRALabel.setBounds(175, 273, 99, 20);
		layeredPane.add(registerRALabel);
		
		registerRBLabel = new JLabel("");
		registerRBLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		registerRBLabel.setHorizontalAlignment(SwingConstants.CENTER);
		registerRBLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		registerRBLabel.setBackground(Color.WHITE);
		registerRBLabel.setOpaque(true);
		registerRBLabel.setBounds(324, 273, 114, 20);
		layeredPane.add(registerRBLabel);
		
		bSelectLabel = new JLabel("");
		bSelectLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		bSelectLabel.setHorizontalAlignment(SwingConstants.CENTER);
		bSelectLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		bSelectLabel.setOpaque(true);
		bSelectLabel.setBackground(Color.WHITE);
		bSelectLabel.setBounds(248, 349, 79, 28);
		layeredPane.add(bSelectLabel);
		
		immediateLabel = new JLabel("");
		immediateLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		immediateLabel.setHorizontalAlignment(SwingConstants.CENTER);
		immediateLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		immediateLabel.setOpaque(true);
		immediateLabel.setBackground(Color.WHITE);
		immediateLabel.setBounds(370, 335, 120, 42);
		layeredPane.add(immediateLabel);
		
		aluInputA = new JLabel("");
		aluInputA.setFont(new Font("Times New Roman", Font.BOLD, 14));
		aluInputA.setHorizontalAlignment(SwingConstants.CENTER);
		aluInputA.setHorizontalTextPosition(SwingConstants.CENTER);
		aluInputA.setBackground(Color.WHITE);
		aluInputA.setOpaque(true);
		aluInputA.setBounds(214, 508, 73, 32);
		layeredPane.add(aluInputA);
		
		aluInputB = new JLabel("");
		aluInputB.setFont(new Font("Times New Roman", Font.BOLD, 14));
		aluInputB.setHorizontalAlignment(SwingConstants.CENTER);
		aluInputB.setHorizontalTextPosition(SwingConstants.CENTER);
		aluInputB.setOpaque(true);
		aluInputB.setBackground(Color.WHITE);
		aluInputB.setBounds(324, 508, 59, 32);
		layeredPane.add(aluInputB);
		
		aluOutput = new JLabel("");
		aluOutput.setFont(new Font("Times New Roman", Font.BOLD, 14));
		aluOutput.setHorizontalAlignment(SwingConstants.CENTER);
		aluOutput.setHorizontalTextPosition(SwingConstants.CENTER);
		aluOutput.setBackground(Color.WHITE);
		aluOutput.setOpaque(true);
		aluOutput.setBounds(246, 567, 114, 32);
		layeredPane.add(aluOutput);
		
		registerRZLabel = new JLabel("");
		registerRZLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		registerRZLabel.setHorizontalAlignment(SwingConstants.CENTER);
		registerRZLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		registerRZLabel.setOpaque(true);
		registerRZLabel.setBackground(Color.WHITE);
		registerRZLabel.setBounds(248, 641, 110, 28);
		layeredPane.add(registerRZLabel);
		
		registerRMLabel = new JLabel("");
		registerRMLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		registerRMLabel.setHorizontalAlignment(SwingConstants.CENTER);
		registerRMLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		registerRMLabel.setOpaque(true);
		registerRMLabel.setBackground(Color.WHITE);
		registerRMLabel.setBounds(466, 641, 114, 28);
		layeredPane.add(registerRMLabel);
		
		memoryAccessLabel = new JLabel("");
		memoryAccessLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		memoryAccessLabel.setHorizontalAlignment(SwingConstants.CENTER);
		memoryAccessLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		memoryAccessLabel.setBackground(Color.WHITE);
		memoryAccessLabel.setOpaque(true);
		memoryAccessLabel.setBounds(606, 679, 71, 42);
		layeredPane.add(memoryAccessLabel);
		
		memoryDataLabel = new JLabel("");
		memoryDataLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		memoryDataLabel.setHorizontalAlignment(SwingConstants.CENTER);
		memoryDataLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		memoryDataLabel.setOpaque(true);
		memoryDataLabel.setBackground(Color.WHITE);
		memoryDataLabel.setBounds(606, 720, 71, 54);
		layeredPane.add(memoryDataLabel);
		
		returnAddressLabel = new JLabel("");
		returnAddressLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		returnAddressLabel.setHorizontalAlignment(SwingConstants.CENTER);
		returnAddressLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		returnAddressLabel.setBackground(Color.WHITE);
		returnAddressLabel.setOpaque(true);
		returnAddressLabel.setBounds(417, 765, 105, 42);
		layeredPane.add(returnAddressLabel);
		
		ySelectLabel = new JLabel("");
		ySelectLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		ySelectLabel.setHorizontalAlignment(SwingConstants.TRAILING);
		ySelectLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		ySelectLabel.setOpaque(true);
		ySelectLabel.setBackground(Color.WHITE);
		ySelectLabel.setBounds(80, 823, 110, 54);
		layeredPane.add(ySelectLabel);
		
		registerRYLabel = new JLabel("");
		registerRYLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		registerRYLabel.setHorizontalAlignment(SwingConstants.CENTER);
		registerRYLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		registerRYLabel.setBackground(Color.WHITE);
		registerRYLabel.setOpaque(true);
		registerRYLabel.setBounds(248, 913, 110, 20);
		layeredPane.add(registerRYLabel);
		
		addressALabel = new JLabel("");
		addressALabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		addressALabel.setHorizontalAlignment(SwingConstants.CENTER);
		addressALabel.setHorizontalTextPosition(SwingConstants.CENTER);
		addressALabel.setOpaque(true);
		addressALabel.setBackground(Color.WHITE);
		addressALabel.setBounds(150, 84, 81, 20);
		layeredPane.add(addressALabel);
		
		lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(10, 429, 46, 42);
		layeredPane.add(lblNewLabel);
		
		resetButton = new Button("Reset");
		resetButton.addActionListener(new ResetListener());
		resetButton.setBounds(588, 951, 99, 32);
		layeredPane.add(resetButton);
		datapathPicture.setIcon(new ImageIcon(img));
		datapathPicture.setBounds(-10, 0, 697, 983);
		datapathPicture.setOpaque(true);
		layeredPane.add(datapathPicture);
		frame.getContentPane().setLayout(groupLayout);
		frame.setVisible(true);
	}
	public void stageOne(){
		addressALabel.setText(src1Address);
		addressBLabel.setText(src2Address);
	}
	public void stageTwo(){
		registerALabel.setText(source1Name);
		registerBLabel.setText(source2Name);
	}
	public void stageThree()
	{
		if(immediate == null && memoryReference != null)
		{
			result = compute(Integer.parseInt(source1),Integer.parseInt(source2,16));
		}
		else if(immediate == null && memoryReference == null)
		{
			result = compute(Integer.parseInt(source1),Integer.parseInt(source2));
		}
		else if(immediate != null && memoryReference == null)
		{
			result = compute(Integer.parseInt(immediate),Integer.parseInt(source1));
		}
		this.computation = "0x" + Integer.toHexString(result);
		registerRALabel.setText(source1);
		registerRBLabel.setText(source2);
		immediateLabel.setText(immediate);
		bSelectLabel.setText(bSelect);
		aluInputA.setText(source1);
		aluInputB.setText(source2);
		aluOutput.setText(computation);
		
	}
	public void stageFour()
	{
		registerRZLabel.setText(computation);
		ySelectLabel.setText(ySelect);
	}
	public void stageFive()
	{
		registerRYLabel.setText(computation);
		cSelectLabel.setText(cSelect);
	}
	@Override
	public void AddTwoOperands(String destinationName,String source1Name,String source2Name, String source1,
			String source2) {
		// TODO Auto-generated method stub
		this.destinationName = destination;
		this.source1Name = source1Name;
		this.source2Name = source2Name;
		this.source1 = source1;
		this.src1Address = source1;
		this.source2 = source2;
		this.src2Address = source2;
		this.bSelect = "0";
		this.ySelect = "0";
		this.cSelect = "1";
		setAddreses();
	}
	
	@Override
	public void AddOneOperandsrc1Imm(String destinationName,String source2Name,String source2,
			int immediate) {
			this.destinationName = destination;
			this.source2Name = source2Name;
			this.source1 = null;
			this.src2Address = source2;
			this.source2 = source2;
			this.immediate = Integer.toString(immediate);
			this.bSelect = "1";
			this.ySelect = "0";
			this.cSelect = "1";
			setAddreses();
		
	}
	public void AddOneOperandsrc2Imm(String destinationName,String source1Name, String source1,
			int immediate) {
		// TODO Auto-generated method stub
				this.destinationName = destination;
				this.source1Name = source1Name;
				this.source1 = source1;
				this.src1Address = source1;
				this.source2 = null;
				this.immediate = Integer.toString(immediate);
				this.bSelect = "1";
				this.ySelect = "0";
				this.cSelect = "1";
				setAddreses();
	}
	
	public void AddOneOperandMem(String destination, String source,
			String memRef)
	{
		this.destination = "0x";
		this.source1 = source;
		this.src1Address = source1;
		this.memoryReference = memRef;
		this.source2 = memRef;
		this.src2Address = null;
		this.bSelect = "0";
		this.ySelect = "0";
		this.cSelect = "1";
		setAddreses();
	}
	
	
	@Override
	public void AndTwoOperands(String destinationName, String source1Name,String source2Name, String source1,
			String source2) {
		// TODO Auto-generated method stub
		this.destination = destination;
		this.source1 = source1;
		this.src1Address = source1;
		this.source2 = source2;
		this.src2Address = source2;
		this.bSelect = "0";
		this.ySelect = "0";
		this.cSelect = "1";
		setAddreses();
	}
	
	@Override
	public void StoreTwoOperands(String destination, String source) {
		// TODO Auto-generated method stub
		this.destination = destination;
		this.source1 = source;
		this.src1Address = source1;
		this.source2 = null;
		this.cSelect = "0";
		setAddreses();
	}
	@Override
	public void Call(String destination) {
		// TODO Auto-generated method stub
		this.destination = destination;
		this.source1 = null;
		this.source2 = null;
		setAddreses();
	}
	@Override
	public void LoadTwoOperands(String destination, String source) {
		// TODO Auto-generated method stub
		this.destination = destination;
		this.source1 = source;
		this.src1Address = source1;
		this.source2 = null;
		setAddreses();
	}
	@Override
	public void AndOneOperandImm(String destination, String source1,
			int immediate) {
		// TODO Auto-generated method stub
		this.source1 = source1;
		this.source2 = null;
		setAddreses();
	}

	private void setAddreses()
	{
		destAddress = createAddress();
		this.destAddress = "0x" +  String.format("%4s",destAddress).replace(' ','0');

		if(src1Address != null && src2Address != null)
		{
			
			src1Address = createAddress();
			src2Address = createAddress();
			while(sourceAddress1 == sourceAddress2)
			{
				src2Address = createAddress();
			}
			this.src1Address = "0x" +  src1Address;
			this.src2Address = "0x" +  src2Address;
		}
		else if(src1Address != null && src2Address == null && memoryReference == null)
		{
			src1Address = createAddress();
			this.src1Address = "0x" + src1Address;
		}
		else if(src1Address == null && src2Address != null && memoryReference == null)
		{
			src2Address = createAddress();
			this.src2Address = "0x" + src2Address;
		}
		else if(src1Address != null && src2Address == null && memoryReference != null)
		{
			src1Address = createAddress();
			this.src1Address = "0x" + String.format("%4s",src1Address).replace(' ','0');
			this.src2Address = "0x" + String.format("%4s",memoryReference).replace(' ','0');

		}
		else if(src1Address == null && src2Address != null && memoryReference != null)
		{
			src2Address = createAddress();
			this.src1Address = "0x" + src1Address;
			this.src1Address = "0x" + memoryReference;
		}
	}

	private String createAddress()
	{
		address = "";
		 for (int i = 0; i < 4; i++) 
		 {
			 address += hexNum.charAt(ran.nextInt(hexCount));   
		 }
		 return address;
		
	}
	private int compute(int num1, int num2)
	{
		result = num1 + num2;
		return result;
	}
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "Next Stage");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
			
			if(count == 1)
			{
				stageOne();
			}
			else if(count == 2)
			{
				stageTwo();
			}
			else if (count == 3)
			{
				stageThree();
			}
			else if (count == 4)
			{
				stageFour();
			}
			else if (count == 5)
			{
				stageFive();
			}
			else if (count == 6)
			{
				destAddress = destination;
				addressCLabel.setText(destAddress);
				registerCLabel.setText(destinationName);
				rf_WriteLabel.setText("1");
				nextStageButton.setVisible(false);
				resetButton.setVisible(true);
			}
			count++;
		}
	}
	private class ResetListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			count = 1;
			addressCLabel.setText("");
			cSelectLabel.setText("");
			registerCLabel.setText("");
			registerALabel.setText("");
			registerBLabel.setText("");
			registerRALabel.setText("");
			registerRBLabel.setText("");
			rf_WriteLabel.setText("");
			bSelectLabel.setText("");
			immediateLabel.setText("");
			aluInputA.setText("");
			aluInputB.setText("");
			aluOutput.setText("");
			registerRZLabel.setText("");
			registerRMLabel.setText("");
			memoryAccessLabel.setText("");
			memoryDataLabel.setText("");
			returnAddressLabel.setText("");
			registerRYLabel.setText("");
			ySelectLabel.setText("");
			addressALabel.setText("");
			addressBLabel.setText("");
			resetButton.setVisible(false);
			nextStageButton.setVisible(true);
		}
	}


}
