public class Load{
	public Load(){}
}
