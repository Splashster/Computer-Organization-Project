import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JComboBox;

import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.LayoutStyle.ComponentPlacement;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.Random;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JRadioButton;

import java.awt.Component;


public class InstructionEntry extends JFrame {

	private JPanel contentPane;
	private JComboBox instructionBox;
	private String selectedInstruction;
	private Random rand;
	private boolean clear;
	private boolean valid;
	private boolean validEntry;
	private JTextField destinationTextField;
	private JTextField source1Textfield;
	private JTextField source2Textfield;
	private JLabel destinationLabel;
	private JLabel source1Label;
	private JLabel source2Label;
    private int count;
	protected int immediate;
	protected String source1, source2,source1RegName, source2RegName, destinationRegName,source1Value,source2Value;
	protected String memoryReference = "";
	private JRadioButton setSource2RadioButton;
	private JTextField source1RegisterValue;
	private JTextField source2RegisterValue;
	private JLabel reg1ValueMustBeLabel;
	private JLabel reg2ValueMustBeLabel;
	private JButton submitButton;
	private JRadioButton setSource1RadioButton;
	private JFrame frame;
	
	final String hexNum = "0123456789ABCDEF";
    final int hexCount = hexNum.length();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InstructionEntry frame = new InstructionEntry();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public InstructionEntry() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 650, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
		String[] instructions = {"-SELECT-","ADD","AND","LOAD","STORE","CALL"};
		instructionBox = new JComboBox(instructions);
		instructionBox.addActionListener(new InstructionChoice());
			
		instructionBox.setFont(new Font("Times New Roman", Font.BOLD, 22));
		
		JLabel instrutionSelectionLabel = new JLabel("Instruction Selection");
		instrutionSelectionLabel.setAlignmentY(Component.TOP_ALIGNMENT);
		instrutionSelectionLabel.setHorizontalAlignment(SwingConstants.CENTER);
		instrutionSelectionLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
		
		destinationTextField = new JTextField();
		destinationTextField.setAlignmentX(Component.LEFT_ALIGNMENT);
		destinationTextField.setColumns(10);
		destinationTextField.setVisible(false);
		
		source1Textfield = new JTextField();
		source1Textfield.setAlignmentX(Component.LEFT_ALIGNMENT);
		source1Textfield.setColumns(10);
		source1Textfield.setVisible(false);
		
		source2Textfield = new JTextField();
		source2Textfield.setAlignmentX(Component.LEFT_ALIGNMENT);
		source2Textfield.setColumns(10);
		source2Textfield.setVisible(false);
		
		destinationLabel = new JLabel("Destination");
		destinationLabel.setAlignmentY(Component.TOP_ALIGNMENT);
		destinationLabel.setAlignmentX(SwingConstants.LEFT);
		destinationLabel.setHorizontalAlignment(SwingConstants.CENTER);
		destinationLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
		destinationLabel.setVisible(false);
		
		source1Label = new JLabel("Source 1");
		source1Label.setAlignmentY(Component.TOP_ALIGNMENT);
		source1Label.setFont(new Font("Times New Roman", Font.BOLD, 18));
		source1Label.setHorizontalAlignment(SwingConstants.CENTER);
		source1Label.setVisible(false);
		
		source2Label = new JLabel("Source 2");
		source2Label.setAlignmentY(Component.TOP_ALIGNMENT);
		source2Label.setFont(new Font("Times New Roman", Font.BOLD, 18));
		source2Label.setHorizontalAlignment(SwingConstants.CENTER);
		source2Label.setVisible(false);
		
		rand = new Random();
		valid = false;
		count = 0;
		 
		submitButton = new JButton("Submit");
		submitButton.setAlignmentY(Component.BOTTOM_ALIGNMENT);
		submitButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		submitButton.setVerticalAlignment(SwingConstants.BOTTOM);
		submitButton.setFont(new Font("Times New Roman", Font.BOLD, 18));
		submitButton.addActionListener(new SubmitListener());
		submitButton.setVisible(false);
		
		setSource1RadioButton = new JRadioButton("Set Source 1 Register Value");
		setSource1RadioButton.setFont(new Font("Times New Roman", Font.BOLD, 12));
		setSource1RadioButton.addActionListener(new SetValueListener());
		setSource1RadioButton.setVisible(false);
		
		setSource2RadioButton = new JRadioButton("Set Source 2 Register Value");
		setSource2RadioButton.setFont(new Font("Times New Roman", Font.BOLD, 12));
		setSource2RadioButton.addActionListener(new SetValueListener());
		setSource2RadioButton.setVisible(false);
		
		source1RegisterValue = new JTextField();
		source1RegisterValue.setColumns(10);
		source1RegisterValue.setVisible(false);
		
		source2RegisterValue = new JTextField();
		source2RegisterValue.setColumns(10);
		source2RegisterValue.setVisible(false);
		
		reg1ValueMustBeLabel = new JLabel("Value must be number and a maximum of 5 digits");
		reg1ValueMustBeLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 12));
		reg1ValueMustBeLabel.setVisible(false);
		
		reg2ValueMustBeLabel = new JLabel("Value must be number and a maximum of 5 digits");
		reg2ValueMustBeLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 12));
		reg2ValueMustBeLabel.setVisible(false);
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addComponent(submitButton, GroupLayout.DEFAULT_SIZE, 632, Short.MAX_VALUE)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(setSource2RadioButton, GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
						.addComponent(setSource1RadioButton, GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
							.addComponent(instrutionSelectionLabel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(instructionBox, Alignment.LEADING, 0, 157, Short.MAX_VALUE)))
					.addGap(23)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(source2RegisterValue, GroupLayout.PREFERRED_SIZE, 132, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
							.addComponent(reg2ValueMustBeLabel, GroupLayout.PREFERRED_SIZE, 256, GroupLayout.PREFERRED_SIZE)
							.addContainerGap())
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(destinationLabel, GroupLayout.PREFERRED_SIZE, 126, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
									.addComponent(source1Label, GroupLayout.PREFERRED_SIZE, 126, GroupLayout.PREFERRED_SIZE)
									.addGap(10)
									.addComponent(source2Label, GroupLayout.PREFERRED_SIZE, 126, GroupLayout.PREFERRED_SIZE))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(destinationTextField, GroupLayout.PREFERRED_SIZE, 132, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(source1Textfield, GroupLayout.PREFERRED_SIZE, 125, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
									.addComponent(source2Textfield, GroupLayout.PREFERRED_SIZE, 125, GroupLayout.PREFERRED_SIZE)))
							.addGap(10))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(source1RegisterValue, GroupLayout.PREFERRED_SIZE, 132, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
							.addComponent(reg1ValueMustBeLabel, GroupLayout.PREFERRED_SIZE, 256, GroupLayout.PREFERRED_SIZE)
							.addContainerGap())))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
						.addComponent(instrutionSelectionLabel, Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE, false)
							.addComponent(source2Label, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE)
							.addComponent(destinationLabel, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE)
							.addComponent(source1Label, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE)))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
							.addComponent(source2Textfield, GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE)
							.addComponent(source1Textfield, GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE)
							.addComponent(destinationTextField, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE))
						.addComponent(instructionBox, GroupLayout.PREFERRED_SIZE, 32, Short.MAX_VALUE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(setSource1RadioButton, GroupLayout.PREFERRED_SIZE, 35, GroupLayout.PREFERRED_SIZE)
						.addComponent(source1RegisterValue, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
						.addComponent(reg1ValueMustBeLabel, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(setSource2RadioButton, GroupLayout.PREFERRED_SIZE, 35, GroupLayout.PREFERRED_SIZE)
						.addComponent(source2RegisterValue, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
						.addComponent(reg2ValueMustBeLabel, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 60, Short.MAX_VALUE)
					.addComponent(submitButton, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE))
		);
		contentPane.setLayout(gl_contentPane);
	 }
	
		 private class InstructionChoice implements ActionListener
		  {
			public void actionPerformed(ActionEvent e) {
				instructionBox = (JComboBox<String>) e.getSource();
				  selectedInstruction = (String)instructionBox.getSelectedItem();
				  if(selectedInstruction.equals("-select-"))
				  {
					    destinationTextField.setVisible(false);
					    destinationLabel.setVisible(false);
					    
					    source1Textfield.setVisible(false);
					    source1Label.setVisible(false);
						setSource1RadioButton.setVisible(false);
						source1RegisterValue.setVisible(false);
						reg1ValueMustBeLabel.setVisible(false);

					    source2Textfield.setVisible(false);
					    source2Label.setVisible(false);
						setSource2RadioButton.setVisible(false);
						source2RegisterValue.setVisible(false);
						reg2ValueMustBeLabel.setVisible(false);
						
					    submitButton.setVisible(false);
							
				  }
				  else if(selectedInstruction.equals("ADD"))
					{
					    destinationTextField.setVisible(true);
						destinationLabel.setVisible(true);

					    source1Textfield.setVisible(true);
					    source1Label.setVisible(true);
						setSource1RadioButton.setVisible(true);
						setSource1RadioButton.setSelected(false);
						source1RegisterValue.setVisible(false);
						reg1ValueMustBeLabel.setVisible(false);

					    source2Textfield.setVisible(true);
					    source2Label.setVisible(true);
					    setSource2RadioButton.setSelected(false);
						setSource2RadioButton.setVisible(true);
						source2RegisterValue.setVisible(false);
						reg2ValueMustBeLabel.setVisible(false);
						
					    submitButton.setVisible(true);
					    
					}
					else if(selectedInstruction.equals("AND"))
					{
						destinationTextField.setVisible(true);
						destinationLabel.setVisible(true);
						
					    source1Textfield.setVisible(true);
					    source1Label.setVisible(true);
						setSource1RadioButton.setVisible(true);
						setSource1RadioButton.setSelected(false);
						source1RegisterValue.setVisible(false);
						reg1ValueMustBeLabel.setVisible(false);

					    source2Textfield.setVisible(true);
					    source2Label.setVisible(true);
					    setSource2RadioButton.setSelected(false);
						setSource2RadioButton.setVisible(true);
						source2RegisterValue.setVisible(false);
						reg2ValueMustBeLabel.setVisible(false);
						
					    submitButton.setVisible(true);
					}
					else if(selectedInstruction.equals("LOAD"))
					{
						destinationTextField.setVisible(true);
						destinationLabel.setVisible(true);

					    source1Textfield.setVisible(true);
					    source1Label.setVisible(true);
					    setSource1RadioButton.setSelected(false);
						setSource1RadioButton.setVisible(true);
						source1RegisterValue.setVisible(false);
						reg1ValueMustBeLabel.setVisible(false);

					    source2Textfield.setVisible(false);
					    source2Label.setVisible(false);
					    setSource2RadioButton.setSelected(false);
						setSource2RadioButton.setVisible(false);
						source2RegisterValue.setVisible(false);
						reg2ValueMustBeLabel.setVisible(false);
						
					    submitButton.setVisible(true);
					}
					else if(selectedInstruction.equals("STORE"))
					{
						destinationTextField.setVisible(true);
						destinationLabel.setVisible(true);
					    
					    source1Textfield.setVisible(true);
					    source1Label.setVisible(true);
					    setSource1RadioButton.setSelected(false);
						setSource1RadioButton.setVisible(true);
						source1RegisterValue.setVisible(false);
						reg1ValueMustBeLabel.setVisible(false);

					    source2Textfield.setVisible(false);
					    source2Label.setVisible(false);
					    setSource2RadioButton.setSelected(false);
						setSource2RadioButton.setVisible(false);
						source2RegisterValue.setVisible(false);
						reg2ValueMustBeLabel.setVisible(false);
						
					    submitButton.setVisible(true);
					}
					else if(selectedInstruction.equals("CALL"))
					{
						destinationTextField.setVisible(true);
						destinationLabel.setVisible(true);
						
					    source1Textfield.setVisible(false);
					    source1Label.setVisible(false);
					    setSource1RadioButton.setSelected(false);
						setSource1RadioButton.setVisible(false);
						source1RegisterValue.setVisible(false);
						reg1ValueMustBeLabel.setVisible(false);

					    source2Textfield.setVisible(false);
					    source2Label.setVisible(false);
					    source2RegisterValue.setVisible(false);
						setSource2RadioButton.setVisible(false);
						source2RegisterValue.setVisible(false);
						reg2ValueMustBeLabel.setVisible(false);
						
					    submitButton.setVisible(true);
					}
				  } 
			}
		 private class SetValueListener implements ActionListener
		 {
			 public void actionPerformed(ActionEvent e) 
			 {
				    if(setSource1RadioButton.isSelected())
				    {
				    	source1RegisterValue.setVisible(true);
						reg1ValueMustBeLabel.setVisible(true);
				    }
				    else
				    {
				    	source1RegisterValue.setVisible(false);
						reg1ValueMustBeLabel.setVisible(false);
				    }
				    if(setSource2RadioButton.isSelected())
				    {
				    	source2RegisterValue.setVisible(true);
						reg2ValueMustBeLabel.setVisible(true);
				    }
				    else
				    {
				    	source2RegisterValue.setVisible(false);
						reg2ValueMustBeLabel.setVisible(false);
				    }
			 }
		 }
		 private class SubmitListener implements ActionListener
		  {
			 public void actionPerformed(ActionEvent e) 
			 {
				 validEntry = true;
				  if(selectedInstruction.equals("ADD"))
				  {

					 if(isNumeric(destinationTextField.getText()))
				     {
					     alert("The Destination cannot be an immediate value!");
					 }
					 else if(isAddress(source1Textfield.getText()) && isAddress(source2Textfield.getText()))
					 {
						 alert("Cannot do a memory to memory ADD!");
					 }
					 if(isNumeric(source1Textfield.getText()) && !isNumeric(source2Textfield.getText()) && !isAddress(source2Textfield.getText()))
					 {
						 source2RegName = source2Textfield.getText();
						 destinationRegName = destinationTextField.getText();
						 source2Value = source2RegisterValue.getText();
						 immediate = Integer.parseInt(source1Textfield.getText());
						 if(source2Value != null && !source2Value.isEmpty())
						 {
							 source2 = source2Value;
						 }
						 else
						 {
							 source2 = Integer.toString(rand.nextInt(9999) + 1);
						 }
						 if(!validCount(source2))
						 {
							 alert("Maximum number of digits allowed in register is 5!");
							 validEntry = false;
						 }
						 for(int i = 0; i < source2.length(); i++)
						 {
							 if(!Character.isDigit(source2.charAt(i)))
							 {
								 alert(source2RegName + " value should only contain numeric values!");
								 validEntry = false;
							 }
						 }
						 
						 if(validEntry == true)
						 {
							 close();
							 Add add = new Add();
							 add.AddOneOperandsrc1Imm(destinationRegName,source2RegName, source2, immediate);
						 }
					 }
					 else if((!isNumeric(source1Textfield.getText()) && isNumeric(source2Textfield.getText())) && !isAddress(source1Textfield.getText()))
					 {
						 destinationRegName = destinationTextField.getText();
						 source1RegName = source1Textfield.getText();
						 source1Value = source1RegisterValue.getText();
						 immediate = Integer.parseInt(source2Textfield.getText());
						 if(!source1Value.isEmpty() && source1Value != null)
						 {
							 source1 = source1Value;
						 }
						 else
						 {
							 source1 = Integer.toString(rand.nextInt(9999) + 1);
						 }
						 if(!validCount(source1))
						 {
							 alert("Maximum number of digits allowed in register is 5!");
							 validEntry = false;
						 }
						
						 for(int i = 0; i < source1.length(); i++)
						 {
							 if(!Character.isDigit(source1.charAt(i)))
							 {
								 alert(source1RegName + " value should only contain numeric values!");
								 validEntry = false;
							 }
						 }
						 
						 if(validEntry == true)
						 {
							 Add add = new Add();
							 add.AddOneOperandsrc2Imm(destinationRegName,source1RegName, source1, immediate);
							 close();
						 }
					 }
					 else if((!isNumeric(source1Textfield.getText()) && !isNumeric(source2Textfield.getText())) && !isAddress(source1Textfield.getText()) && !isAddress(source2Textfield.getText()))
					 {
						 source1RegName = source1Textfield.getText();
						 source2RegName = source2Textfield.getText();
						 destinationRegName = destinationTextField.getText();
						 source1Value = source1RegisterValue.getText();
						 source2Value = source2RegisterValue.getText();
						 if(!source1Value.isEmpty() && source1Value != null)
						 {
							 source1 = source1Value;
						 }
						 else
						 {
							 source1 = Integer.toString(rand.nextInt(9999) + 1);
						 }
						 if(!source2Value.isEmpty() && source2Value != null)
						 {
							 source2 = source2Value;
						 }
						 else
						 {
							 source2 = Integer.toString(rand.nextInt(9999) + 1);
						 }
						 if(!validCount(source1) || !validCount(source2))
						 {
							 alert("Maximum number of digits allowed in register is 5!");
							 validEntry = false;
						 }

						 for(int i = 0; i < source1.length(); i++)
						 {
							 if(!Character.isDigit(source1.charAt(i)))
							 {
								 alert(source1RegName + " value should only contain numeric values!");
								 validEntry = false;
							 }
						 }
						 for(int i = 0; i < source2.length(); i++)
						 {
							 if(!Character.isDigit(source2.charAt(i)))
							 {
								 alert(source2RegName + " value should only contain numeric values!");
								 validEntry = false;
							 }
						 }
						
						 if(validEntry == true)
						 {
							 Add add = new Add();
							 add.AddTwoOperands( destinationRegName,source1RegName,source2RegName, source1, source2);
							 close();
						 }
					 }
					 else if(isAddress(source1Textfield.getText()) && !isAddress(source2Textfield.getText()))
					 {
						 for (int i = 0; i < 4; i++) 
						 {
							 memoryReference += hexNum.charAt(rand.nextInt(hexCount));
						        
						        
						    }
						 source2RegName = source2RegisterValue.getText();
						 destinationRegName = destinationTextField.getText();
						 
						 if(source2RegName != null && !source2RegName.isEmpty())
						 {
							 source2 = source2RegisterValue.getText();
						 }
						 else
						 {
							 source2 = Integer.toString(rand.nextInt(9999) + 1);
						 }
						 for(int i = 0; i < source2.length(); i++)
						 {
							 if(!Character.isDigit(source2.charAt(i)))
							 {
								 alert(source2RegName + " value should only contain numeric values!");
								 validEntry = false;
							 }
						 }
						 if(!validCount(source2))
						 {
							 alert("Maximum number of digits allowed in register is 5!");
							 validEntry = false;
						 }
						 if(validEntry == true)
						 {
							 close();
							 Add add = new Add();
							 add.AddOneOperandMem(destinationRegName, source2, memoryReference);
							 
						 }
					 }
					 else if(!isAddress(source1Textfield.getText()) && isAddress(source2Textfield.getText()))
					 {
						 for (int i = 0; i < 4; i++) 
						 {
							 memoryReference += hexNum.charAt(rand.nextInt(hexCount));   
						  }
						 source1RegName = source1RegisterValue.getText();
						 destinationRegName = destinationTextField.getText();
						 System.out.println(source1RegisterValue.getText());
						 if(source1RegName != null && !source1RegName.isEmpty())
						 {
							 source1 = source1RegisterValue.getText();
						 }
						 else
						 {
							 source1 = Integer.toString(rand.nextInt(9999) + 1);
						 }
						 for(int i = 0; i < source1.length(); i++)
						 {
							 if(!Character.isDigit(source1.charAt(i)))
							 {
								 alert(source1RegName + " value should only contain numeric values!");
								 validEntry = false;
							 }
						 }
						 if(!validCount(source1))
						 {
							 alert("Maximum number of digits allowed in register is 5!");
							 validEntry = false;
						 }
						 if(validEntry == true)
						 {
							 close();
							 Add add = new Add();
							 add.AddOneOperandMem(destinationRegName, source1, memoryReference);
							 
						 }
					 }
					 else
					 {
						 alert("Cannot ADD 2 Immediate Values!");
					 }
				  }
				  else  if(selectedInstruction.equals("AND"))
				  {
					  
					     if(isNumeric(destinationTextField.getText()))
						 {
							 alert("The Destination cannot be an immediate value!");
						 }
						 else if(isAddress(source1Textfield.getText()) && isAddress(source2Textfield.getText()))
						 {
							 alert("Cannot do a memory to memory AND!");
						 }
					     else if(isNumeric(source1Textfield.getText()) && !isNumeric(source2Textfield.getText()))
						 {
							 immediate = Integer.parseInt(source1Textfield.getText());
							 source2 = source2Textfield.getText();
							 destinationRegName = destinationTextField.getText();
							 new DataPathModel();
							 close();
						 }
						 else if((!isNumeric(source1Textfield.getText()) && isNumeric(source2Textfield.getText())))
						 {
							 source1 = source1Textfield.getText();
							 //System.out.println(source1);
							 immediate = Integer.parseInt(source2Textfield.getText());
							 destinationRegName = destinationTextField.getText();
							 new DataPathModel();
							 close();
						 }
						 else if((!isNumeric(source1Textfield.getText()) && !isNumeric(source2Textfield.getText())))
						 {
							 source1 = source1Textfield.getText();
							 source2 = source2Textfield.getText();
							 destinationRegName = destinationTextField.getText();
							 new DataPathModel();
							 close();
						 }
						 
						 else
						 {
							 alert("Cannot AND 2 Immediate Values!");
						 }
				  }
				  else  if(selectedInstruction.equals("LOAD"))
				  {
					  if(isNumeric(destinationTextField.getText()))
					   {
							 alert("The Destination cannot be an immediate value!");
					   }
					  else if(isNumeric(source1Textfield.getText()))
					  {
					    immediate = Integer.parseInt(source1Textfield.getText());
					    destinationRegName = destinationTextField.getText();
					    new DataPathModel();
					    close();
					  }
					  else if(isAddress(source1Textfield.getText()))
					  {
						  for (int i = 0; i < 4; i++) {
								 memoryReference += hexNum.charAt(rand.nextInt(hexCount));
							        System.out.print(memoryReference);
							        
							    }
						  destinationRegName = destinationTextField.getText();
						  new DataPathModel();
						  close();
					  }
				  }
				  else  if(selectedInstruction.equals("STORE"))
				  {
					  if(isNumeric(destinationTextField.getText()))
					  {
							 alert("The Destination cannot be an immediate value!");
					  }
					  else if(isAddress(source1Textfield.getText()))
					  {
						  for (int i = 0; i < 5; i++) {
								 memoryReference += hexNum.charAt(rand.nextInt(hexCount));
							        System.out.print(memoryReference);
							        
							    }
						  new DataPathModel();
						  close();
					  }
					 source1 = source1Textfield.getText();
					 destinationRegName = destinationTextField.getText();
					 new DataPathModel();
					 close();
				  }
				  else  if(selectedInstruction.equals("CALL"))
				  {
					  if(isNumeric(destinationTextField.getText()))
					  {
							 alert("The Destination cannot be an immediate value!");
					  }
					  else if(isAddress(source1Textfield.getText()))
					  {
						  for (int i = 0; i < 4; i++) {
								 memoryReference += hexNum.charAt(rand.nextInt(hexCount));
							        System.out.print(memoryReference);
							        
							    }
						  new DataPathModel();
						  close();
					  }
					  else
					  {
						  destinationRegName = destinationTextField.getText(); 
						 new DataPathModel();
						 close();
					  }
					  
				  }
			  } 
			 }
		 
		 public boolean isNumeric(String source)
		 {
		 	try
		 	{
		 		int d = Integer.parseInt(source);
		 	}
		 	catch(NumberFormatException e)
		 	{
		 		return false;
		 	}
		 	return true;
		 }

		 public boolean isAddress(String source)
		 {
		 	boolean validReference = false;
		 	char test;
		 	if(source.length() <= 1)
		 	{
		 		validReference = false;
		 	}
		 	else if(source.charAt(0) == '[' && source.charAt(source.length()-1) == ']')
		 	{
		 		for(int i = 1; i < source.length()-1; i++)
		 		{
		 			test = source.charAt(i);
		 			if(Character.isLetterOrDigit(test))
		 			{
		 				validReference = true;
		 			}
		 			else
		 			{
		 				validReference = false;
		 				alert("Invalid character inside memeory reference!");
		 				break;
		 			}
		 		}
		 		
		 	}
		 	else if(source.charAt(0) == '[' && source.charAt(source.length()-1) != ']')
		 	{
		 		alert("Missing ] for source register or invalid entry after memory reference!");
		 	}
		 	else if(source.charAt(0) != '[' && source.charAt(source.length()-1) == ']')
		 	{
		 		alert("Missing [ for source register or invalid entry after memory reference!");
		 	}
		 	/*for(int i = 0; i < source.length(); i++)
		 	{
		 		if(source.charAt(i) == '[')
		 		{
		 			
		 		}
		 	}*/
		 	return validReference;
		 }
		 public boolean validCount(String check)
		 {
		 	count = 0;
		 	for(int i = 0; i < check.length(); i++)
		 	 {
		 		 if(Character.isDigit(check.charAt(i)))
		 		 {
		 			 count++;
		 		 }
		 	 }
		 	if(count <= 5)
		 	{
		 		valid = true;
		 	}
		 	else
		 	{
		 		valid = false;
		 	}
		 	return valid;
		 }
		 public void close() {
			  dispose();
		  }
		 public void alert(String message)
		 {
		 	JOptionPane.showMessageDialog(frame ,message, "Invalid Instruction", JOptionPane.ERROR_MESSAGE);
		 }
	}
