public class Add extends DataPathModel implements InstructionsInterface {
	
	//private int src1 = 0;
	//private int src2 = 0;
	//private int total = 0;
	public Add(){
		super();
	}

	public void AddTwoOperands(String destinationName,String source1Name,String source2Name,String source1,String source2){
		super.AddTwoOperands(destinationName,source1Name,source2Name, source1, source2);
	}

	public void AddOneOperandsrc1Imm(String destinationName,String source2Name,String source2,int immediate){
		
		super.AddOneOperandsrc1Imm(destinationName, source2Name, source2, immediate);
	}
	public void AddOneOperandsrc2Imm(String destinationName,String source1Name, String source1, int immediate){
		super.AddOneOperandsrc2Imm(destinationName, source1Name, source1, immediate);
	}
	public void AddOneOperandMem(String destination, String source,String memRef)
	{
		super.AddOneOperandMem(destination,source,memRef);
	}
	

	
	/*public int AddTwoOperands(String source1, String source2)
	{
		src1 = Integer.parseInt(source1);
		src2 = Integer.parseInt(source2);
		total = src1 + src2;
		return total;
	}*/
	
	public void StoreTwoOperands(String destination, String source){
		super.StoreTwoOperands(destination, source);
	}

	public void Call(String destination){}

	public void LoadTwoOperands(String destination, String source){}

	public void AndOneOperandImm(String destination,String source1,int immediate){
		super.AndOneOperandImm(destination, source1, immediate);
	}


	public void AndTwoOperands(String destinationName,String source1Name, String source2Name, String source1,
			String source2) {
		super.AndTwoOperands(destinationName, source1Name, source2Name, source1, source2);
		
	}

	
}
