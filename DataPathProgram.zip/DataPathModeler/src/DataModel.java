import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class DataModel extends JFrame{
	public DataModel() throws IOException
	{
	   JFrame frame = new JFrame();
	   JLabel label = new JLabel("");
	   Image img = new ImageIcon(this.getClass().getResource("Datapath.jpg")).getImage();
	   label.setIcon(new ImageIcon(img));
	   frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	   frame.setLocationRelativeTo(null);
	   frame.getContentPane().add(label);
	   frame.pack();
   	   frame.setSize(695,1010);
	   frame.setResizable(false);
	   frame.setTitle("DataPathModel");
	   frame.setVisible(true);
	}

}
