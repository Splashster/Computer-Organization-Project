public interface InstructionsInterface{
	

	public void AddTwoOperands(String destinationName,String source1Name, String source2Name,String source1,String source2);
	
	public void AddOneOperandImm(String destinationName,String source1Name,String source1,int immediate);
	
	public void AddOneOperandsrc1Mem(String destinationName,String source1Name, String source2Name, String source2,String memRef);
	
	public void AddOneOperandsrc2Mem(String destinationName,String source2Name, String source1Name, String source1,String memRef);
	
	public void AddMemandImm(String destinationName,String source1Name,String memRef, int immediate);
	
    public void AndTwoOperands(String destinationName,String source1Name, String source2Name,String source1,String source2);
	
	public void AndOneOperandImm(String destinationName,String source1Name,String source1,int immediate);
	
	public void AndOneOperandsrc1Mem(String destinationName,String source1Name, String source2Name, String source2,String memRef);
	
	public void AndOneOperandsrc2Mem(String destinationName,String source2Name, String source1Name, String source1,String memRef);
	
	public void AndMemandImm(String destinationName,String source1Name,String memRef, int immediate);

	public void LoadOperand(String destinationName, String sourceName,String source);
	
	public void LoadMemRef(String destinationName,String sourceName,String memoryReference,int immediate);
	
	public void StoreMemRef(String destination,String source1Name ,String memRef, int immediate); 

	public void Call(String destinationName, String memoryReference);

	

	public void AndOneOperandImm(String destination,String source1,int immediate);
}