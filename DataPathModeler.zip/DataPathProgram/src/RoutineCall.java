import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.SwingConstants;
import javax.swing.JLayeredPane;
import javax.swing.LayoutStyle.ComponentPlacement;

import java.awt.Color;
import java.awt.Button;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;


public class RoutineCall extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	/**
	 * Launch the application.
	 */


	private JLabel pcEnableLabel;	
	private int phases = 1;
	private JLabel pcTempLabel;
	private JLabel pcLabel;
	private JLabel incSelect;
	private JLabel pcSelectetLabel;
	private JLabel pcValueLabel;
	private JLabel incValueLabel;
	private int programCounter;
	private int pcSelect;
	private int pcEnabled;
	private JLabel adderValue;
	private DataPathModel model;
	private JLabel raLabel;
	private String ra;
	/**
	 * Create the frame.
	 */

	
	public RoutineCall(String ra,int programCounter, int pcSelect, int pcEnabled, DataPathModel model) {
		this.programCounter = programCounter;
		this.pcSelect = pcSelect;
		this.pcEnabled = pcEnabled;
		this.model = model;
		this.ra = ra;
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 660, 550);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		this.addWindowListener(new CloseListener());
		JLayeredPane layeredPane = new JLayeredPane();
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(layeredPane, GroupLayout.PREFERRED_SIZE, 648, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addComponent(layeredPane, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 518, Short.MAX_VALUE)
		);
		
		pcTempLabel = new JLabel("");
		pcTempLabel.setHorizontalAlignment(SwingConstants.CENTER);
		pcTempLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		pcTempLabel.setBackground(Color.WHITE);
		pcTempLabel.setOpaque(true);
		layeredPane.setLayer(pcTempLabel, 0);
		
		
		pcTempLabel.setBounds(22, 341, 141, 26);
		layeredPane.add(pcTempLabel);
		
		pcLabel = new JLabel("");
		pcLabel.setHorizontalAlignment(SwingConstants.CENTER);
		pcLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		pcLabel.setOpaque(true);
		pcLabel.setBackground(Color.WHITE);
		pcLabel.setBounds(191, 166, 146, 36);
		layeredPane.add(pcLabel);
		
		pcEnableLabel = new JLabel("");
		pcEnableLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		pcEnableLabel.setHorizontalAlignment(SwingConstants.TRAILING);
		pcEnableLabel.setOpaque(true);
		pcEnableLabel.setBackground(Color.WHITE);
		pcEnableLabel.setBounds(55, 166, 98, 36);
		layeredPane.add(pcEnableLabel);
		
		incSelect = new JLabel("");
		incSelect.setFont(new Font("Times New Roman", Font.BOLD, 16));
		incSelect.setVerticalAlignment(SwingConstants.TOP);
		incSelect.setHorizontalAlignment(SwingConstants.CENTER);
		incSelect.setOpaque(true);
		incSelect.setBackground(Color.WHITE);
		incSelect.setBounds(346, 230, 98, 36);
		layeredPane.add(incSelect);
		
		pcSelectetLabel = new JLabel("");
		pcSelectetLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		pcSelectetLabel.setHorizontalAlignment(SwingConstants.TRAILING);
		pcSelectetLabel.setOpaque(true);
		pcSelectetLabel.setBackground(Color.WHITE);
		pcSelectetLabel.setBounds(55, 79, 98, 36);
		layeredPane.add(pcSelectetLabel);
		
		pcValueLabel = new JLabel("");
		pcValueLabel.setOpaque(true);
		pcValueLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		pcValueLabel.setHorizontalAlignment(SwingConstants.CENTER);
		pcValueLabel.setBackground(Color.WHITE);
		pcValueLabel.setBounds(231, 341, 84, 36);
		layeredPane.add(pcValueLabel);
		
		adderValue = new JLabel("");
		adderValue.setFont(new Font("Times New Roman", Font.BOLD, 16));
		adderValue.setHorizontalAlignment(SwingConstants.CENTER);
		adderValue.setBackground(Color.WHITE);
		adderValue.setBounds(279, 407, 127, 42);
		layeredPane.add(adderValue);
		
		incValueLabel = new JLabel("");
		incValueLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		incValueLabel.setHorizontalAlignment(SwingConstants.CENTER);
		incValueLabel.setBackground(Color.WHITE);
		incValueLabel.setBounds(360, 341, 84, 36);
		layeredPane.add(incValueLabel);
		
		
		Button nextPhaseButton = new Button("Next phase");
		nextPhaseButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(phases == 1){
					phaseOne();
					phases++;
				}else if(phases == 2){
					phaseTwo();
					phases++;
				}else if(phases == 3){
					phaseThree();
					phases++;
				}
				else
				{
					close();
				}
			}
			
		});
		nextPhaseButton.setBounds(540, 476, 98, 26);
		layeredPane.add(nextPhaseButton);
		
		raLabel = new JLabel("");
		raLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		raLabel.setVerticalAlignment(SwingConstants.BOTTOM);
		raLabel.setHorizontalAlignment(SwingConstants.CENTER);
		raLabel.setOpaque(true);
		raLabel.setBackground(Color.WHITE);
		raLabel.setBounds(136, 0, 141, 36);
		layeredPane.add(raLabel);
		
		JLabel imageLabel = new JLabel("");
		imageLabel.setBounds(0, 0, 650, 518);
		layeredPane.add(imageLabel);
		imageLabel.setVerticalAlignment(SwingConstants.TOP);
		Image img = new ImageIcon(this.getClass().getResource("copy.png")).getImage();
		imageLabel.setIcon(new ImageIcon(img));
		
		
		contentPane.setLayout(gl_contentPane);
		
		pcValueLabel.setText(""+this.programCounter);
		pcLabel.setText(""+this.programCounter);
		incValueLabel.setText("4");
		incSelect.setText("0");
		programCounter += 4;
		adderValue.setText(""+programCounter);
		pcEnableLabel.setText("1");
		model.disableEnableNextStage(false);
	}
	private void phaseOne(){
		pcSelectetLabel.setText("0");
		pcSelectetLabel.setBackground(Color.YELLOW);
		raLabel.setText(ra);
		raLabel.setBackground(Color.YELLOW);
	}
	private void phaseTwo(){
		if(pcSelect == 0)
		{
			pcSelectetLabel.setBackground(Color.WHITE);
			raLabel.setBackground(Color.WHITE);
			pcLabel.setText(ra);
			pcLabel.setBackground(Color.YELLOW);
		}
	}
	private void phaseThree(){
		pcLabel.setBackground(Color.WHITE);
		pcValueLabel.setText(ra);
		pcValueLabel.setBackground(Color.YELLOW);
		pcTempLabel.setText(ra);
		pcTempLabel.setBackground(Color.YELLOW);
	}
	private void close()
	{
		dispose();
		model.disableEnableNextStage(true);
	}
	private class CloseListener implements WindowListener
	{

		@Override
		public void windowActivated(WindowEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void windowClosed(WindowEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void windowClosing(WindowEvent arg0) {
			// TODO Auto-generated method stub
			model.disableEnableNextStage(true);
			
		}

		@Override
		public void windowDeactivated(WindowEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void windowDeiconified(WindowEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void windowIconified(WindowEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void windowOpened(WindowEvent arg0) {
			// TODO Auto-generated method stub
			
		}
		
	}
}


