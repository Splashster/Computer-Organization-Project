import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.SwingConstants;
import javax.swing.JLayeredPane;
import javax.swing.LayoutStyle.ComponentPlacement;

import java.awt.Color;
import java.awt.Button;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class RoutineCall extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	/**
	 * Launch the application.
	 */


	private JLabel pcEnableLabel;	
	private int phases = 1;
	private JLabel pcTempLabel;
	private JLabel pcLabel;
	private JLabel incSelect;
	private JLabel pcSelectetLabel;
	private JLabel pcValueLabel;
	private JLabel branchOffsetValueLabel;
	private int programCounter;
	private int pcSelect;
	private int pcEnabled;
	private JLabel adderValue;
	private DataPathModel model;
	/**
	 * Create the frame.
	 */
	public RoutineCall(int programCounter, int pcSelect, int pcEnabled, DataPathModel model) {
		this.programCounter = programCounter;
		this.pcSelect = pcSelect;
		this.pcEnabled = pcEnabled;
		this.model = model;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 660, 550);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLayeredPane layeredPane = new JLayeredPane();
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(layeredPane, GroupLayout.PREFERRED_SIZE, 648, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addComponent(layeredPane, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 518, Short.MAX_VALUE)
		);
		
		pcTempLabel = new JLabel("");
		pcTempLabel.setBackground(Color.WHITE);
		pcTempLabel.setOpaque(true);
		layeredPane.setLayer(pcTempLabel, 0);
		
		
		pcTempLabel.setBounds(22, 341, 141, 26);
		layeredPane.add(pcTempLabel);
		
		pcLabel = new JLabel("");
		pcLabel.setOpaque(true);
		pcLabel.setBackground(Color.WHITE);
		pcLabel.setBounds(191, 166, 146, 36);
		layeredPane.add(pcLabel);
		
		pcEnableLabel = new JLabel("");
		pcEnableLabel.setOpaque(true);
		pcEnableLabel.setBackground(Color.WHITE);
		pcEnableLabel.setBounds(44, 166, 98, 36);
		layeredPane.add(pcEnableLabel);
		
		incSelect = new JLabel("");
		incSelect.setOpaque(true);
		incSelect.setBackground(Color.WHITE);
		incSelect.setBounds(346, 230, 98, 36);
		layeredPane.add(incSelect);
		
		pcSelectetLabel = new JLabel("");
		pcSelectetLabel.setOpaque(true);
		pcSelectetLabel.setBackground(Color.WHITE);
		pcSelectetLabel.setBounds(44, 80, 98, 36);
		layeredPane.add(pcSelectetLabel);
		
		pcValueLabel = new JLabel("");
		pcValueLabel.setHorizontalAlignment(SwingConstants.CENTER);
		pcValueLabel.setBackground(Color.WHITE);
		pcValueLabel.setBounds(231, 341, 61, 26);
		layeredPane.add(pcValueLabel);
		
		adderValue = new JLabel("");
		adderValue.setHorizontalAlignment(SwingConstants.CENTER);
		adderValue.setBackground(Color.WHITE);
		adderValue.setBounds(311, 423, 61, 26);
		layeredPane.add(adderValue);
		
		branchOffsetValueLabel = new JLabel("");
		branchOffsetValueLabel.setHorizontalAlignment(SwingConstants.CENTER);
		branchOffsetValueLabel.setBackground(Color.WHITE);
		branchOffsetValueLabel.setBounds(383, 341, 61, 26);
		layeredPane.add(branchOffsetValueLabel);
		
		Button nextPhaseButton = new Button("Next phase");
		nextPhaseButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println(" NEXT " + phases);
				if(phases == 1){
					phaseOne();
					phases++;
				}else if(phases == 2){
					phaseTwo();
					phases++;
				}else if(phases == 3){
					phaseThree();
					phases++;
				}
			}
			
		});
		nextPhaseButton.setBounds(540, 476, 98, 26);
		layeredPane.add(nextPhaseButton);
		
		JLabel imageLabel = new JLabel("");
		imageLabel.setBounds(0, 0, 650, 518);
		layeredPane.add(imageLabel);
		imageLabel.setVerticalAlignment(SwingConstants.TOP);
		Image img = new ImageIcon(this.getClass().getResource("copy.png")).getImage();
		imageLabel.setIcon(new ImageIcon(img));
		
		JLabel label = new JLabel("New label");
		label.setBounds(311, 451, 61, 16);
		layeredPane.add(label);
		
		
		contentPane.setLayout(gl_contentPane);
	}
	private void phaseOne(){
		pcValueLabel.setText(""+this.programCounter);
		branchOffsetValueLabel.setText("4");
		programCounter += 4;
		adderValue.setText(""+programCounter);
	}
	private void phaseTwo(){
		pcSelectetLabel.setText(""+this.pcSelect);
	}
	private void phaseThree(){
		if(pcSelect == 1)
		{
			pcValueLabel.setText(""+this.programCounter);
			pcTempLabel.setText(""+this.programCounter);
			model.setProgramCounter(this.programCounter);
		}
	}
}


