public class Add extends DataPathModel implements InstructionsInterface {
	
	//private int src1 = 0;
	//private int src2 = 0;
	//private int total = 0;
	public Add(){
		super();
	}

	public void AddTwoOperands(String destinationName,String source1Name,String source2Name,String source1,String source2){
		super.AddTwoOperands(destinationName,source1Name,source2Name, source1, source2);
		}

    public void AddOneOperandImm(String destinationName,String source1Name,String source1,int immediate) {
    	super.AddOneOperandImm(destinationName, source1Name, source1, immediate);
    }
	
    public void AddOneOperandsrc1Mem(String destinationName,String source1Name,String source2Name, String source2,String memRef) {
    	super.AddOneOperandsrc1Mem(destinationName, source1Name,source2Name, source2, memRef);
    }
	
	public void AddOneOperandsrc2Mem(String destinationName, String source1Name,String source2Name, String source1,String memRef) {
		super.AddOneOperandsrc2Mem(destinationName, source1Name,source2Name, source1, memRef);
	}
	
	public void AddMemandImm(String destination,String memRef, int immediate) {
		super.AddMemandImm(destination, destination, memRef, immediate);
	}

	public void AndTwoOperands(String destinationName,String source1Name,String source2Name,String source1,String source2){
		super.AndTwoOperands(destinationName,source1Name,source2Name, source1, source2);
		}

    public void AndOneOperandImm(String destinationName,String source1Name,String source1,int immediate) {
    	super.AndOneOperandImm(destinationName, source1Name, source1, immediate);
    }
	
    public void AndOneOperandsrc1Mem(String destinationName,String source1Name,String source2Name, String source2,String memRef) {
    	super.AndOneOperandsrc1Mem(destinationName, source1Name,source2Name, source2, memRef);
    }
	
	public void AndOneOperandsrc2Mem(String destinationName, String source1Name,String source2Name, String source1,String memRef) {
		super.AndOneOperandsrc2Mem(destinationName, source1Name,source2Name, source1, memRef);
	}
	
	public void AndMemandImm(String destination,String memRef, int immediate) {
		super.AndMemandImm(destination, destination, memRef, immediate);
	}
	
	public void LoadOperand(String destinationName,String sourceName,String source) {
		super.LoadOperand(destinationName, sourceName, source);
	}
	
	public void LoadMemRef(String destination,String sourceName,String source, int immediate) {
		super.LoadMemRef(destination, sourceName, source,immediate);
	}
	
	public void StoreMemRef(String destination, String source1Name,String source, int immediate){
		super.StoreMemRef(destination, source1Name,source,immediate);
	}

	public void Call(String destinationName, String memoryReference) {
		super.Call(destinationName,memoryReference);
	}

	

	public void AndOneOperandImm(String destination,String source1,int immediate){
		super.AndOneOperandImm(destination, source1, immediate);
	}


	
}
