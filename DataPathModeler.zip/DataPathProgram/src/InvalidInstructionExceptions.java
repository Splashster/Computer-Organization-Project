public class InvalidInstructionExceptions extends RuntimeException{
	
   public InvalidInstructionExceptions(String error)
   {
      super(error);
   }
}