import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLayeredPane;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import java.awt.Color;

import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.AbstractAction;

import java.awt.event.ActionEvent;
import java.util.Random;

import javax.swing.Action;
import javax.swing.JTextPane;

import java.awt.Button;
import java.awt.event.ActionListener;

import javax.swing.SwingConstants;

import java.awt.Font;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;


public class DataPathModel implements InstructionsInterface{
	private JFrame frame;
	protected String source1,source2,immediate,destination,memoryReference,src1Address
	,src2Address,destAddress,address,bSelect,cSelect,ySelect,computation,source1Name,source2Name,destinationName;
	protected int sourceAddress1, sourceAddress2,destinationAddress;
	protected int programCounter, pcSelect, pcEnabled;
	private JLabel addressBLabel;
	private final Action action = new SwingAction();
	private JLabel addressCLabel;
	private JLabel cSelectLabel;
	private JLabel registerCLabel;
	private JLabel registerALabel;
	private JLabel registerBLabel;
	private JLabel registerRALabel;
	private JLabel registerRBLabel;
	private JLabel rf_WriteLabel;
	private JLabel bSelectLabel;
	private JButton nextStageButton;
	private JLabel immediateLabel;
	private JLabel aluInputA;
	private JLabel aluInputB;
	private JLabel aluOutput;
	private JLabel registerRZLabel;
	private JLabel registerRMLabel;
	private JLabel returnAddressLabel;
	private JLabel registerRYLabel;
	private JLabel ySelectLabel;
	private Random ran = new Random();
	private JLabel addressALabel;
	private int count = 1;
	private Button resetButton;
	private int result = 0;
	private String option;
	private  StringBuilder build = new StringBuilder();
    private boolean closed = false;
	final String hexNum = "0123456789ABCDEF";
    final int hexCount = hexNum.length();
    private JMenuBar menuBar;
    private JMenu mnNewMenu;
    private JLabel stage2HighLabel;
    private JLabel stage3HighLabel;
    private JLabel stage4HighLabel;
    private JLabel stage5HighLabelPart1;
    private JLabel stage5HighLabelPart2;
    private JLabel memDataLabel;
    private JLabel memAddLabel;
    private String num;
    
	
	public DataPathModel() {
		initialize();
	}


	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 695, 1030);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		frame.setLocation(dim.width/2-frame.getSize().width/2, dim.height/2-frame.getSize().height/2);
		JLayeredPane layeredPane = new JLayeredPane();
		GroupLayout groupLayout = new GroupLayout(frame.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addComponent(layeredPane, GroupLayout.DEFAULT_SIZE, 695, Short.MAX_VALUE)
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addComponent(layeredPane, GroupLayout.DEFAULT_SIZE, 1010, Short.MAX_VALUE)
		);
		
		addressBLabel = new JLabel();
		addressBLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		addressBLabel.setHorizontalAlignment(SwingConstants.CENTER);
		addressBLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		addressBLabel.setOpaque(true);
		addressBLabel.setBackground(Color.WHITE);
		addressBLabel.setBounds(150, 160, 92, 20);
		layeredPane.add(addressBLabel);
		
		nextStageButton = new JButton("Next Stage");
		nextStageButton.setAction(action);
		nextStageButton.setBackground(Color.LIGHT_GRAY);
		nextStageButton.setBounds(588, 971, 99, 32);
		layeredPane.add(nextStageButton);
		
		
		
		rf_WriteLabel = new JLabel("");
		rf_WriteLabel.setForeground(Color.BLACK);
		rf_WriteLabel.setVerticalAlignment(SwingConstants.BOTTOM);
		rf_WriteLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		rf_WriteLabel.setHorizontalAlignment(SwingConstants.CENTER);
		rf_WriteLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		rf_WriteLabel.setOpaque(true);
		rf_WriteLabel.setBackground(Color.WHITE);
		rf_WriteLabel.setBounds(389, 31, 60, 31);
		layeredPane.add(rf_WriteLabel);
		JLabel datapathPicture = new JLabel();
		datapathPicture.setHorizontalTextPosition(SwingConstants.CENTER);
		datapathPicture.setHorizontalAlignment(SwingConstants.CENTER);
		datapathPicture.setBackground(Color.WHITE);
		Image img = new ImageIcon(this.getClass().getResource("Datapath.jpg")).getImage();
		
		addressCLabel = new JLabel("");
		addressCLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		addressCLabel.setOpaque(true);
		addressCLabel.setBackground(Color.WHITE);
		addressCLabel.setBounds(389, 170, 81, 28);
		layeredPane.add(addressCLabel);
		
		cSelectLabel = new JLabel("");
		cSelectLabel.setVerticalAlignment(SwingConstants.TOP);
		cSelectLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		cSelectLabel.setHorizontalAlignment(SwingConstants.CENTER);
		cSelectLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		cSelectLabel.setBackground(Color.WHITE);
		cSelectLabel.setForeground(Color.BLACK);
		cSelectLabel.setOpaque(true);
		cSelectLabel.setBounds(569, 201, 81, 42);
		layeredPane.add(cSelectLabel);
		
		registerCLabel = new JLabel("");
		registerCLabel.setForeground(Color.BLACK);
		registerCLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		registerCLabel.setHorizontalAlignment(SwingConstants.CENTER);
		registerCLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		registerCLabel.setBackground(Color.WHITE);
		registerCLabel.setOpaque(true);
		registerCLabel.setBounds(255, 72, 114, 32);
		layeredPane.add(registerCLabel);
		
		registerALabel = new JLabel("");
		registerALabel.setForeground(Color.BLACK);
		registerALabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		registerALabel.setHorizontalAlignment(SwingConstants.CENTER);
		registerALabel.setHorizontalTextPosition(SwingConstants.CENTER);
		registerALabel.setOpaque(true);
		registerALabel.setBackground(Color.WHITE);
		registerALabel.setBounds(254, 201, 52, 32);
		layeredPane.add(registerALabel);
		
		registerBLabel = new JLabel("");
		registerBLabel.setForeground(Color.BLACK);
		registerBLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		registerBLabel.setHorizontalAlignment(SwingConstants.CENTER);
		registerBLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		registerBLabel.setBackground(Color.WHITE);
		registerBLabel.setOpaque(true);
		registerBLabel.setBounds(317, 201, 52, 32);
		layeredPane.add(registerBLabel);
		
		registerRALabel = new JLabel("");
		registerRALabel.setForeground(Color.BLACK);
		registerRALabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		registerRALabel.setHorizontalAlignment(SwingConstants.CENTER);
		registerRALabel.setHorizontalTextPosition(SwingConstants.CENTER);
		registerRALabel.setBackground(Color.WHITE);
		registerRALabel.setOpaque(true);
		registerRALabel.setBounds(171, 290, 120, 32);
		layeredPane.add(registerRALabel);
		
		registerRBLabel = new JLabel("");
		registerRBLabel.setOpaque(true);
		registerRBLabel.setForeground(Color.BLACK);
		registerRBLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		registerRBLabel.setHorizontalAlignment(SwingConstants.CENTER);
		registerRBLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		registerRBLabel.setBackground(Color.WHITE);
		registerRBLabel.setBounds(328, 290, 121, 32);
		layeredPane.add(registerRBLabel);
		
		bSelectLabel = new JLabel("");
		bSelectLabel.setForeground(Color.BLACK);
		bSelectLabel.setVerticalAlignment(SwingConstants.BOTTOM);
		bSelectLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		bSelectLabel.setHorizontalAlignment(SwingConstants.CENTER);
		bSelectLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		bSelectLabel.setOpaque(true);
		bSelectLabel.setBackground(Color.WHITE);
		bSelectLabel.setBounds(259, 364, 73, 42);
		layeredPane.add(bSelectLabel);
		
		immediateLabel = new JLabel("");
		immediateLabel.setForeground(Color.BLACK);
		immediateLabel.setVerticalAlignment(SwingConstants.BOTTOM);
		immediateLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		immediateLabel.setHorizontalAlignment(SwingConstants.CENTER);
		immediateLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		immediateLabel.setOpaque(true);
		immediateLabel.setBackground(Color.WHITE);
		immediateLabel.setBounds(377, 364, 114, 28);
		layeredPane.add(immediateLabel);
		
		aluInputA = new JLabel("");
		aluInputA.setForeground(Color.BLACK);
		aluInputA.setFont(new Font("Times New Roman", Font.BOLD, 16));
		aluInputA.setHorizontalAlignment(SwingConstants.CENTER);
		aluInputA.setHorizontalTextPosition(SwingConstants.CENTER);
		aluInputA.setBackground(Color.WHITE);
		aluInputA.setOpaque(true);
		aluInputA.setBounds(218, 528, 73, 28);
		layeredPane.add(aluInputA);
		
		aluInputB = new JLabel("");
		aluInputB.setForeground(Color.BLACK);
		aluInputB.setFont(new Font("Times New Roman", Font.BOLD, 16));
		aluInputB.setHorizontalAlignment(SwingConstants.CENTER);
		aluInputB.setHorizontalTextPosition(SwingConstants.CENTER);
		aluInputB.setOpaque(true);
		aluInputB.setBackground(Color.WHITE);
		aluInputB.setBounds(329, 528, 75, 28);
		layeredPane.add(aluInputB);
		
		aluOutput = new JLabel("");
		aluOutput.setForeground(Color.BLACK);
		aluOutput.setFont(new Font("Times New Roman", Font.BOLD, 16));
		aluOutput.setHorizontalAlignment(SwingConstants.CENTER);
		aluOutput.setHorizontalTextPosition(SwingConstants.CENTER);
		aluOutput.setBackground(Color.WHITE);
		aluOutput.setOpaque(true);
		aluOutput.setBounds(255, 587, 114, 32);
		layeredPane.add(aluOutput);
		
		registerRZLabel = new JLabel("");
		registerRZLabel.setForeground(Color.BLACK);
		registerRZLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		registerRZLabel.setHorizontalAlignment(SwingConstants.CENTER);
		registerRZLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		registerRZLabel.setOpaque(true);
		registerRZLabel.setBackground(Color.WHITE);
		registerRZLabel.setBounds(248, 660, 121, 31);
		layeredPane.add(registerRZLabel);
		
		registerRMLabel = new JLabel("");
		registerRMLabel.setForeground(Color.BLACK);
		registerRMLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		registerRMLabel.setHorizontalAlignment(SwingConstants.CENTER);
		registerRMLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		registerRMLabel.setOpaque(true);
		registerRMLabel.setBackground(Color.WHITE);
		registerRMLabel.setBounds(468, 660, 120, 31);
		layeredPane.add(registerRMLabel);
		
		returnAddressLabel = new JLabel("");
		returnAddressLabel.setForeground(Color.BLACK);
		returnAddressLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		returnAddressLabel.setHorizontalAlignment(SwingConstants.CENTER);
		returnAddressLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		returnAddressLabel.setBackground(Color.WHITE);
		returnAddressLabel.setOpaque(true);
		returnAddressLabel.setBounds(422, 793, 105, 32);
		layeredPane.add(returnAddressLabel);
		
		ySelectLabel = new JLabel("");
		ySelectLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		ySelectLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		ySelectLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		ySelectLabel.setOpaque(true);
		ySelectLabel.setBackground(Color.WHITE);
		ySelectLabel.setBounds(132, 845, 66, 43);
		layeredPane.add(ySelectLabel);
		
		registerRYLabel = new JLabel("");
		registerRYLabel.setForeground(Color.BLACK);
		registerRYLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		registerRYLabel.setHorizontalAlignment(SwingConstants.CENTER);
		registerRYLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		registerRYLabel.setBackground(Color.WHITE);
		registerRYLabel.setOpaque(true);
		registerRYLabel.setBounds(248, 931, 121, 28);
		layeredPane.add(registerRYLabel);
		
		stage2HighLabel = new HighLight(73, 151);
		stage2HighLabel.setBounds(0, 135, 73, 151);
		layeredPane.add(stage2HighLabel);
		
	
		stage3HighLabel = new HighLight(73, 366);
		stage3HighLabel.setBounds(0, 286, 73, 366);
		layeredPane.add(stage3HighLabel);
		
		stage4HighLabel = new HighLight(75, 267);
		stage4HighLabel.setBounds(-2, 653, 75, 267);
		layeredPane.add(stage4HighLabel);
		
		stage5HighLabelPart1 = new HighLight(75, 80);
		stage5HighLabelPart1.setBounds(-2, 921, 75, 82);
		layeredPane.add(stage5HighLabelPart1);
		
		stage5HighLabelPart2 = new HighLight(75, 114);
		stage5HighLabelPart2.setBounds(0, 21, 75, 114);
		layeredPane.add(stage5HighLabelPart2);
		
		stage2HighLabel.setVisible(false);
		stage3HighLabel.setVisible(false);
		stage4HighLabel.setVisible(false);
		stage5HighLabelPart1.setVisible(false);
		stage5HighLabelPart2.setVisible(false);
		
		addressALabel = new JLabel("");
		addressALabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		addressALabel.setHorizontalAlignment(SwingConstants.CENTER);
		addressALabel.setHorizontalTextPosition(SwingConstants.CENTER);
		addressALabel.setOpaque(true);
		addressALabel.setBackground(Color.WHITE);
		addressALabel.setBounds(150, 107, 92, 20);
		layeredPane.add(addressALabel);
		
		resetButton = new Button("Reset");
		resetButton.addActionListener(new ResetListener());
		resetButton.setBounds(588, 971, 99, 32);
		layeredPane.add(resetButton);
		
		memDataLabel = new JLabel("");
		memDataLabel.setForeground(Color.BLACK);
		memDataLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		memDataLabel.setHorizontalAlignment(SwingConstants.CENTER);
		memDataLabel.setBackground(Color.WHITE);
		memDataLabel.setOpaque(true);
		memDataLabel.setBounds(600, 748, 87, 50);
		layeredPane.add(memDataLabel);
		
		memAddLabel = new JLabel("");
		memAddLabel.setOpaque(true);
		memAddLabel.setBackground(Color.WHITE);
		memAddLabel.setBounds(600, 692, 87, 50);
		layeredPane.add(memAddLabel);
		
		
		
		
		datapathPicture.setIcon(new ImageIcon(img));
		datapathPicture.setBounds(0, 21, 687, 982);
		layeredPane.add(datapathPicture);
		
		
		
		menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 687, 21);
		layeredPane.add(menuBar);
		
		mnNewMenu = new JMenu("New menu");
		JMenuItem mitem = new JMenuItem("New Instruction Entry");
		mitem.addActionListener(new NewInstructionListener());
		mnNewMenu.add(mitem);
		menuBar.add(mnNewMenu);
		frame.getContentPane().setLayout(groupLayout);
		frame.setVisible(true);
	}
	public void stageOne(){
		if(source1Name != null && (source1Name.equalsIgnoreCase(destinationName) || source1Name.equalsIgnoreCase('[' + destinationName + ']')))
		{
			addressALabel.setText("0x" + src1Address);
			addressALabel.setBackground(Color.YELLOW);
		}
		else if(src1Address != null)
		{
			addressALabel.setText(src1Address);
			addressALabel.setBackground(Color.YELLOW);
		}
		else
		{
			addressALabel.setText(src1Address);
		}
		if(source2Name != null && (source2Name.equalsIgnoreCase(destinationName) || source2Name.equalsIgnoreCase('[' + destinationName + ']')))
		{
			addressBLabel.setText("0x" + src2Address);
			addressBLabel.setBackground(Color.YELLOW);
		}
		else if(src2Address != null)
		{
			addressBLabel.setText(src2Address);
			addressBLabel.setBackground(Color.YELLOW);
		}
		else if(src1Address == null && src2Address == null && destAddress != null)
		{
			addressALabel.setText(destAddress);
			addressALabel.setBackground(Color.YELLOW);
		}
		else
		{
			addressBLabel.setText(src2Address);
		}
	}
	public void stageTwo(){
		addressALabel.setBackground(Color.WHITE);
		addressBLabel.setBackground(Color.WHITE);
		if(source1Name != null)
		{
			registerALabel.setText(source1Name.toUpperCase());
			registerALabel.setBackground(Color.YELLOW);
		}
		if(source2Name != null)
		{
			registerBLabel.setText(source2Name.toUpperCase());
			registerBLabel.setBackground(Color.YELLOW);
		}
		if(source1Name == null && source2Name == null && destinationName != null)
		{
			registerALabel.setText(destinationName.toUpperCase());
			registerALabel.setBackground(Color.YELLOW);
		}
		stage2HighLabel.setVisible(true);
		stage3HighLabel.setVisible(false);
		stage4HighLabel.setVisible(false);
		stage5HighLabelPart1.setVisible(false);
		stage5HighLabelPart2.setVisible(false);
		
	}
	public void stageThree()
	{
		if(!option.equals("Call"))
		{
					
			registerALabel.setBackground(Color.WHITE);
			registerBLabel.setBackground(Color.WHITE);
			if(option.equals("Add"))
			{
				if(immediate == null && memoryReference != null && source1.equals(memoryReference))
				{
					result = compute(Integer.parseInt(source2),Integer.parseInt(source1,16));
					this.computation = "0x" + String.format("%4s",Integer.toHexString(result).toUpperCase().replace(' ','0'));
				}
				else if(immediate == null && memoryReference != null && source2.equals(memoryReference))
				{
					result = compute(Integer.parseInt(source1),Integer.parseInt(source2,16));
					this.computation = "0x" + String.format("%4s",Integer.toHexString(result).toUpperCase().replace(' ','0'));
				}
				else if(immediate == null && memoryReference == null && source1 != null && source2 != null)
				{
					result = compute(Integer.parseInt(source1),Integer.parseInt(source2));
					this.computation = Integer.toString(result);
				}
				else if(immediate != null && source2 == null && memoryReference == null)
				{
					result = compute(Integer.parseInt(immediate),Integer.parseInt(source1));
					this.computation = Integer.toString(result);
				}
				else if(immediate != null && memoryReference == null)
				{
					result = compute(Integer.parseInt(immediate),Integer.parseInt(source1));
					this.computation = "0x" + String.format("%4s",Integer.toHexString(result).toUpperCase().replace(' ','0'));
				}
				else if(immediate != null && memoryReference != null)
				{
					result = compute(Integer.parseInt(immediate),Integer.parseInt(source1,16));
					this.computation = "0x" + String.format("%4s",Integer.toHexString(result).toUpperCase().replace(' ','0'));
				}
				if(source1.equals(memoryReference) && source2 != null && immediate == null)
				{
					registerRALabel.setText("0x" + source1.toUpperCase());
					registerRALabel.setBackground(Color.YELLOW);
					aluInputA.setText("0x" + source1.toUpperCase());
					aluInputA.setBackground(Color.YELLOW);
					registerRBLabel.setText(source2);
					registerRBLabel.setBackground(Color.YELLOW);
					aluInputB.setText(source2);
					aluInputB.setBackground(Color.YELLOW);
				}
				if(source1 != null && source2 != null && source2.equals(memoryReference) && immediate == null)
				{
					registerRALabel.setText(source1);
					aluInputA.setText(source1);
					registerRBLabel.setText("0x" + source2.toUpperCase());
					aluInputB.setText("0x" + source2.toUpperCase());
					registerRALabel.setBackground(Color.YELLOW);
					aluInputA.setBackground(Color.YELLOW);
					registerRBLabel.setBackground(Color.YELLOW);
					aluInputB.setBackground(Color.YELLOW);
				}
				if(source2 != null && source1 != null && memoryReference == null && immediate == null)
				{
					registerRALabel.setText(source1);
					aluInputA.setText(source1);
					registerRBLabel.setText(source2);
					aluInputB.setText(source2);
					registerRALabel.setBackground(Color.YELLOW);
					aluInputA.setBackground(Color.YELLOW);
					registerRBLabel.setBackground(Color.YELLOW);
					aluInputB.setBackground(Color.YELLOW);
				}
				else if(immediate != null && memoryReference != null)
				{
					registerRALabel.setText("0x" + source1.toUpperCase());
					aluInputA.setText("0x" + source1.toUpperCase());
					immediateLabel.setBackground(Color.YELLOW);
				}
				if(source1 != null && memoryReference == null && immediate != null)
				{
					registerRALabel.setText(source1);
					aluInputA.setText(source1);
					immediateLabel.setBackground(Color.YELLOW);
				}
				if(source2 == null && immediate != null)
				{
					aluInputB.setText(immediate);
					aluInputB.setBackground(Color.YELLOW);
				}
				immediateLabel.setText(immediate);
				bSelectLabel.setText(bSelect);
				aluOutput.setText(computation);
				bSelectLabel.setBackground(Color.YELLOW);
				aluOutput.setBackground(Color.YELLOW);
	     	}
			else if(option.equals("And"))
			{
				if(immediate == null && memoryReference != null && source1.equals(memoryReference))
				{
					result = compute(Integer.parseInt(source2),Integer.parseInt(source1,16));
					build.append(Integer.toHexString(result));
				    while(build.length() < 4)
				    {
				    	build.insert(0, '0');
				    }
					this.computation = "0x" + build.toString();
				}
				else if(immediate == null && memoryReference != null && source2.equals(memoryReference))
				{
					result = compute(Integer.parseInt(source1),Integer.parseInt(source2,16));
					build.append(Integer.toHexString(result));
				    while(build.length() < 4)
				    {
				    	build.insert(0, '0');
				    }
					this.computation = "0x" + build.toString();
				}
				else if(immediate == null && memoryReference == null && source1 != null && source2 != null)
				{
					result = compute(Integer.parseInt(source1),Integer.parseInt(source2));
					this.computation = Integer.toString(result);
				}
				else if(immediate != null && source2 == null && memoryReference == null)
				{
					result = compute(Integer.parseInt(immediate),Integer.parseInt(source1));
					this.computation = Integer.toString(result);
				}
				else if(immediate != null && memoryReference == null)
				{
					result = compute(Integer.parseInt(immediate),Integer.parseInt(source1));
					build.append(Integer.toHexString(result));
				    while(build.length() < 4)
				    {
				    	build.insert(0, '0');
				    }
					this.computation = "0x" + build.toString();
				}
				else if(immediate != null && memoryReference != null)
				{
					result = compute(Integer.parseInt(immediate),Integer.parseInt(source1,16));
				    build.append(Integer.toHexString(result));
				    while(build.length() < 4)
				    {
				    	build.insert(0, '0');
				    }
					this.computation = "0x" + build.toString();
					
				}
				if(source1.equals(memoryReference) && source2 != null && immediate == null)
				{
					registerRALabel.setText("0x" + String.format("%4s",source1.toUpperCase()).replace(' ','0'));
					aluInputA.setText("0x" + String.format("%4s",source1.toUpperCase()).replace(' ','0'));
					registerRBLabel.setText(source2);
					aluInputB.setText(source2);
					registerRALabel.setBackground(Color.YELLOW);
					aluInputA.setBackground(Color.YELLOW);
					registerRBLabel.setBackground(Color.YELLOW);
					aluInputB.setBackground(Color.YELLOW);
					
				}
				if(source1 != null && source2 != null && source2.equals(memoryReference) && immediate == null)
				{
					registerRALabel.setText(source1);
					aluInputA.setText(source1);
					registerRBLabel.setText("0x" + String.format("%4s",source2.toUpperCase()).replace(' ','0'));
					aluInputB.setText("0x" + String.format("%4s",source2.toUpperCase()).replace(' ','0'));
					registerRALabel.setBackground(Color.YELLOW);
					aluInputA.setBackground(Color.YELLOW);
					registerRBLabel.setBackground(Color.YELLOW);
					aluInputB.setBackground(Color.YELLOW);
				}
				if(source2 != null && source1 != null && memoryReference == null && immediate == null)
				{
					registerRALabel.setText(source1);
					aluInputA.setText(source1);
					registerRBLabel.setText(source2);
					aluInputB.setText(source2);
					registerRALabel.setBackground(Color.YELLOW);
					aluInputA.setBackground(Color.YELLOW);
					registerRBLabel.setBackground(Color.YELLOW);
					aluInputB.setBackground(Color.YELLOW);
				}
				else if(immediate != null && memoryReference != null)
				{
					registerRALabel.setText("0x" + String.format("%4s",source1.toUpperCase()).replace(' ','0'));
					aluInputA.setText("0x" + String.format("%4s",source1.toUpperCase()).replace(' ','0'));
					registerRALabel.setBackground(Color.YELLOW);
					aluInputA.setBackground(Color.YELLOW);
					immediateLabel.setBackground(Color.YELLOW);
				}
				if(source1 != null && memoryReference == null && immediate != null)
				{
					registerRALabel.setText(source1);
					aluInputA.setText(source1);
					registerRALabel.setBackground(Color.YELLOW);
					aluInputA.setBackground(Color.YELLOW);
					immediateLabel.setBackground(Color.YELLOW);
				}
				if(source2 == null && immediate != null)
				{
					aluInputB.setText(immediate);
					aluInputB.setBackground(Color.YELLOW);
				}
				immediateLabel.setText(immediate);
				bSelectLabel.setText(bSelect);
				aluOutput.setText(computation);
				bSelectLabel.setBackground(Color.YELLOW);
				aluOutput.setBackground(Color.YELLOW);
			}
			else if(option.equals("Load"))
			{
				if(source1 != null && memoryReference == null)
				{
					registerRALabel.setText(source1);
					aluInputA.setText(source1);
					registerRALabel.setBackground(Color.YELLOW);
					aluInputA.setBackground(Color.YELLOW);
					aluOutput.setText(source1);
					aluOutput.setBackground(Color.YELLOW);
	
			    }
				else if(source1 != null && memoryReference != null)
				{
					registerRALabel.setText("0x" + String.format("%4s",source1.toUpperCase()).replace(' ','0'));
					aluInputA.setText("0x" + String.format("%4s",source1.toUpperCase()).replace(' ','0'));
					registerRALabel.setBackground(Color.YELLOW);
					aluInputA.setBackground(Color.YELLOW);
					if(immediate != null)
					{
						immediateLabel.setText(immediate);
						immediateLabel.setBackground(Color.YELLOW);
						aluInputB.setText(immediate);
						aluInputB.setBackground(Color.YELLOW);
						result = compute(Integer.parseInt(source1,16),Integer.parseInt(immediate));
						 build.append(Integer.toHexString(result));
						    while(build.length() < 4)
						    {
						    	build.insert(0, '0');
						    }
							this.computation = "0x" + build.toString();
						aluOutput.setText(computation);
						aluOutput.setBackground(Color.YELLOW);
					}
					else
					{
						aluOutput.setText("0x" + String.format("%4s",source1.toUpperCase()).replace(' ','0'));
						aluOutput.setBackground(Color.YELLOW);
					}
				}
				bSelectLabel.setText(bSelect);
				bSelectLabel.setBackground(Color.YELLOW);
			
			}
		}
		else if(option.equals("Store"))
		{
			if(source1 != null && memoryReference == null)
			{
				registerRALabel.setText(source1);
				aluInputA.setText(source1);
				registerRALabel.setBackground(Color.YELLOW);
				aluInputA.setBackground(Color.YELLOW);
				aluOutput.setText(source1);
				aluOutput.setBackground(Color.YELLOW);

		    }
			else if(source1 != null && memoryReference != null)
			{
				registerRALabel.setText("0x" + String.format("%4s",source1.toUpperCase()).replace(' ','0'));
				aluInputA.setText("0x" + String.format("%4s",source1.toUpperCase()).replace(' ','0'));
				registerRALabel.setBackground(Color.YELLOW);
				aluInputA.setBackground(Color.YELLOW);
				if(immediate != null)
				{
					immediateLabel.setText(immediate);
					immediateLabel.setBackground(Color.YELLOW);
					aluInputB.setText(immediate);
					aluInputB.setBackground(Color.YELLOW);
					result = compute(Integer.parseInt(source1,16),Integer.parseInt(immediate));
					 build.append(Integer.toHexString(result));
					    while(build.length() < 4)
					    {
					    	build.insert(0, '0');
					    }
						this.computation = "0x" + build.toString();
					aluOutput.setText(computation);
					aluOutput.setBackground(Color.YELLOW);
				}
				else
				{
					aluOutput.setText("0x" + String.format("%4s",source1.toUpperCase()).replace(' ','0'));
					aluOutput.setBackground(Color.YELLOW);
				}
			}
			bSelectLabel.setText(bSelect);
			bSelectLabel.setBackground(Color.YELLOW);
			

		}
		stage2HighLabel.setVisible(false);
		stage3HighLabel.setVisible(true);
		stage4HighLabel.setVisible(false);
		stage5HighLabelPart1.setVisible(false);
		stage5HighLabelPart2.setVisible(false);
		
	}
	public void stageFour()
	{
		registerRALabel.setBackground(Color.WHITE);
		aluInputA.setBackground(Color.WHITE);
		registerRBLabel.setBackground(Color.WHITE);
		aluInputB.setBackground(Color.WHITE);
		immediateLabel.setBackground(Color.WHITE);
		bSelectLabel.setBackground(Color.WHITE);
		aluOutput.setBackground(Color.WHITE);
		if(option.equals("Call"))
		{
				programCounter = ran.nextInt(9999) + 1;
				pcSelect = 1; 
				pcEnabled = 1;
				try {
					RoutineCall frame = new RoutineCall(programCounter,pcSelect,pcEnabled, this);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
				
		}
	    if(option.equals("Store") && memoryReference != null)
	    {
	    	memAddLabel.setText(computation);
	    	registerRZLabel.setText(computation);
	    	registerRZLabel.setBackground(Color.YELLOW);
	    	memAddLabel.setText(source1);
	    	memAddLabel.setBackground(Color.YELLOW);
	    }
	    else if (option.equals("Store") && memoryReference == null)
	    {
	    	registerRZLabel.setText(source1);
	    	registerRZLabel.setBackground(Color.YELLOW);
	    	memAddLabel.setText(source1);
	    	memAddLabel.setBackground(Color.YELLOW);
	    }
	    else if (option.equals("Load") && memoryReference != null && immediate == null)
	    {
	    	registerRZLabel.setText(source1);
	    	registerRZLabel.setBackground(Color.YELLOW);
	    }
	    else if (option.equals("Load") && memoryReference == null && immediate == null)
	    {
	    	registerRZLabel.setText(source1);
	    	registerRZLabel.setBackground(Color.YELLOW);
	    }
	    else if (option.equals("Load") && memoryReference != null && immediate != null)
	    {
	    	registerRZLabel.setText(computation);
	    	registerRZLabel.setBackground(Color.YELLOW);
	    }
	    else
	    {
	    	registerRZLabel.setText(computation);
	    	registerRZLabel.setBackground(Color.YELLOW);
	    }
		
	    if(!option.equals("Store"))
	    {
	    	ySelectLabel.setText(ySelect);
	    	ySelectLabel.setBackground(Color.YELLOW);
	    }
		
		stage2HighLabel.setVisible(false);
		stage3HighLabel.setVisible(false);
		stage4HighLabel.setVisible(true);
		stage5HighLabelPart1.setVisible(false);
		stage5HighLabelPart2.setVisible(false);
	}
	public void setProgramCounter(int pc){
		System.out.println(" PC VALUE IS " + pc);
	}
	public void stall(boolean stall){
		closed = stall;
	}
	public void stageFive()
	{
		if(!option.equals("Store"))
		{
			registerRMLabel.setBackground(Color.WHITE);
			registerRZLabel.setBackground(Color.WHITE);
			ySelectLabel.setBackground(Color.WHITE);
			addressCLabel.setText("0x" + destAddress);
			registerCLabel.setText(destinationName.toUpperCase());
			rf_WriteLabel.setText("1");
			
			if(ySelect.equals("1"))
			{
				num = Integer.toString(ran.nextInt(9999) + 1);
				registerRYLabel.setText(num);
				memDataLabel.setText(num);
				memDataLabel.setBackground(Color.YELLOW);
			}
			else
			{
				registerRYLabel.setText(computation);
			}
			
			cSelectLabel.setText(cSelect);
			
			addressCLabel.setBackground(Color.YELLOW);
			registerCLabel.setBackground(Color.YELLOW);
			rf_WriteLabel.setBackground(Color.YELLOW);
			registerRYLabel.setBackground(Color.YELLOW);
			cSelectLabel.setBackground(Color.YELLOW);
			stage2HighLabel.setVisible(false);
			stage3HighLabel.setVisible(false);
			stage4HighLabel.setVisible(false);
			stage5HighLabelPart1.setVisible(true);
			stage5HighLabelPart2.setVisible(true);
		}
	}
	@Override
	public void AddTwoOperands(String destinationName,String source1Name,String source2Name, String source1,
			String source2) {
		// TODO Auto-generated method stub
		this.destinationName = destinationName;
		this.source1Name = source1Name;
		this.source2Name = source2Name;
		this.source1 = source1;
		this.src1Address = source1;
		this.source2 = source2;
		this.src2Address = source2;
		this.bSelect = "0";
		this.ySelect = "0";
		this.cSelect = "1";
		option = "Add";
		setAddreses();
	}
	
	 public void AddOneOperandsrc1Mem(String destinationName,String source1Name ,String source2Name, String source2,String memRef) {
		    this.destinationName = destinationName;
		    this.source1Name = source1Name;
			this.source2Name = source2Name;
			this.source2 = source2;
			this.src2Address = source2;
			this.source1 = memRef;
			this.src1Address = null;
			this.memoryReference = memRef;
			this.bSelect = "0";
			this.ySelect = "0";
			this.cSelect = "1";
			option = "Add";
			setAddreses();
	 }
		
		public void AddOneOperandsrc2Mem(String destinationName, String source1Name,String source2Name, String source1,String memRef) {
			this.destinationName = destinationName;
			this.source1Name = source1Name;
			this.source2Name = source2Name;
			this.source1 = source1;
			this.src1Address = source1;
			this.src2Address = null;
			this.source2 = memRef;
			this.memoryReference = memRef;
			this.bSelect = "0";
			this.ySelect = "0";
			this.cSelect = "1";
			option = "Add";
			setAddreses();
		}
		

	public void AddOneOperandImm(String destinationName,String source1Name,String source1,int immediate) {
		// TODO Auto-generated method stub
				this.destinationName = destinationName;
				this.source1Name = source1Name;
				this.source1 = source1;
				this.src1Address = source1;
				this.source2 = null;
				this.immediate = Integer.toString(immediate);
				this.bSelect = "1";
				this.ySelect = "0";
				this.cSelect = "1";
				option = "Add";
				setAddreses();
	}
	

	public void AddMemandImm(String destinationName,String source1Name,String memRef, int immediate)
	{
		this.destinationName = destinationName;
		this.source1Name = source1Name;
		this.memoryReference = memRef;
		this.immediate = Integer.toString(immediate);
		this.source1 = memRef;
		this.src1Address = null;
		this.src2Address = null;
		this.bSelect = "1";
		this.ySelect = "0";
		this.cSelect = "1";
		option = "Add";
		setAddreses();
	}
	
	@Override
	public void AndTwoOperands(String destinationName,String source1Name,String source2Name, String source1,
			String source2) {
		// TODO Auto-generated method stub
		this.destinationName = destinationName;
		this.source1Name = source1Name;
		this.source2Name = source2Name;
		this.source1 = source1;
		this.src1Address = source1;
		this.source2 = source2;
		this.src2Address = source2;
		this.bSelect = "0";
		this.ySelect = "0";
		this.cSelect = "1";
		option = "And";
		setAddreses();
	}
	
	 public void AndOneOperandsrc1Mem(String destinationName,String source1Name ,String source2Name, String source2,String memRef) {
		    this.destinationName = destinationName;
		    this.source1Name = source1Name;
			this.source2Name = source2Name;
			this.source2 = source2;
			this.src2Address = source2;
			this.source1 = memRef;
			this.src1Address = null;
			this.memoryReference = memRef;
			this.bSelect = "0";
			this.ySelect = "0";
			this.cSelect = "1";
			option = "And";
			setAddreses();
	 }
		
		public void AndOneOperandsrc2Mem(String destinationName, String source1Name,String source2Name, String source1,String memRef) {
			this.destinationName = destinationName;
			this.source1Name = source1Name;
			this.source2Name = source2Name;
			this.source1 = source1;
			this.src1Address = source1;
			this.src2Address = null;
			this.source2 = memRef;
			this.memoryReference = memRef;
			this.bSelect = "0";
			this.ySelect = "0";
			this.cSelect = "1";
			option = "And";
			setAddreses();
		}
		
	
	
	public void AndOneOperandImm(String destinationName,String source1Name,String source1,int immediate) {
		// TODO Auto-generated method stub
				this.destinationName = destinationName;
				this.source1Name = source1Name;
				this.source1 = source1;
				this.src1Address = source1;
				this.source2 = null;
				this.immediate = Integer.toString(immediate);
				this.bSelect = "1";
				this.ySelect = "0";
				this.cSelect = "1";
				option = "And";
				setAddreses();
	}
	

	
	public void AndMemandImm(String destinationName,String source1Name,String memRef, int immediate)
	{
		this.destinationName = destinationName;
		this.source1Name = source1Name;
		this.memoryReference = memRef;
		this.immediate = Integer.toString(immediate);
		this.source1 = memRef;
		this.src1Address = null;
		this.src2Address = null;
		this.bSelect = "1";
		this.ySelect = "0";
		this.cSelect = "1";
		option = "And";
		setAddreses();
	}
	
	@Override
	public void LoadOperand(String destinationName, String sourceName,String source) {
		this.destinationName = destinationName;
		this.source1Name = sourceName;
		this.source1 = source;
		this.src1Address = source;
		this.bSelect = "0";
		this.ySelect = "1";
		this.cSelect = "0";
		option = "Load";
		setAddreses();
	}
	
	@Override
	public void LoadMemRef(String destinationName,String sourceName,String memRef,int immediate) {
		source1Name = "";
		for(int i = 0; i < sourceName.length(); i++){
			if(Character.isLetter(sourceName.charAt(i)) ){
				this.source1Name += sourceName.charAt(i);
			}
		}
		
		this.destinationName = destinationName;
		this.memoryReference = memRef;
		this.source1 = memRef;
		this.src1Address = null;
		this.immediate = Integer.toString(immediate);
		if(this.immediate != null && !this.immediate.isEmpty())
		{
			this.bSelect = "1";
		}
		else
		{
			this.bSelect = "0";
		}
		this.ySelect = "1";
		this.cSelect = "1";
		option = "Load";
		setAddreses();
	}
	
	
	@Override
	public void StoreMemRef(String destinationName,String sourceName, String memRef, int immediate) {
		source1Name = "";
		for(int i = 0; i < sourceName.length(); i++){
			if(Character.isLetter(sourceName.charAt(i)) ){
				this.source1Name += sourceName.charAt(i);
			}
		}
		
		this.destinationName = destinationName;
		this.memoryReference = memRef;
		this.source1 = memRef;
		this.src1Address = null;
		this.immediate = Integer.toString(immediate);
		if(this.immediate != null && !this.immediate.isEmpty())
		{
			this.bSelect = "1";
		}
		else
		{
			this.bSelect = "0";
		}
		this.ySelect = "1";
		this.cSelect = "1";
		option = "Store";
		setAddreses();
	}
	@Override
	public void Call(String destinationName,String memRef) {
		source1Name = "";
		for(int i = 0; i < destinationName.length(); i++){
			if(Character.isLetter(destinationName.charAt(i)) ){
				this.source1Name += destinationName.charAt(i);
			}
		}
		
		this.destinationName = destinationName;
		this.memoryReference = memRef;
		option = "Call";
		setAddreses();
	}
	
	
	
	@Override
	public void AndOneOperandImm(String destination, String source1,
			int immediate) {
		// TODO Auto-generated method stub
		this.source1 = source1;
		this.source2 = null;
		setAddreses();
	}

	private void setAddreses()
	{
		if(!option.equals("Call"))
		{	
			destAddress = createAddress();
			this.destAddress = String.format("%4s",destAddress).replace(' ','0');
		}
	
		
		if(src1Address != null && src2Address != null && memoryReference == null && immediate == null)
		{
			if(source1Name.equalsIgnoreCase(destinationName) || source1Name.equalsIgnoreCase('[' + destinationName + ']'))
			{
				this.src1Address = destAddress;
			}
			else
			{
				src1Address = createAddress();
				this.src1Address = "0x" +  src1Address;
			}
			if(source2Name.equals(destinationName)  || source2Name.equalsIgnoreCase('[' + destinationName + ']'))
			{
				this.src2Address = destAddress;
			}
			else if(source2Name.equals(source1Name))
			{
				this.src2Address = src1Address;
			}
			else
			{
				src2Address = createAddress();
				while(src1Address == src2Address)
				{
					src2Address = createAddress();
				}
				
				this.src2Address = "0x" +  src2Address;
			}
				
			
		}
		else if(src1Address != null && src2Address == null && memoryReference == null && immediate != null)
		{
			if(source1Name.equalsIgnoreCase(destinationName) || source1Name.equalsIgnoreCase('[' + destinationName + ']'))
			{
				this.src1Address = destAddress;
			}
			else
			{
				src1Address = createAddress();
				this.src1Address = "0x" + src1Address;
			}
		}
		else if(src1Address == null && src2Address == null && memoryReference != null && immediate != null )
		{
			if(source1Name.equalsIgnoreCase(destinationName) || source1Name.equalsIgnoreCase('[' + destinationName + ']'))
			{
				this.src1Address = destAddress;
				this.memoryReference = destAddress;
				this.source1 = destAddress;
			}
			else
			{
				this.src1Address = "0x" + String.format("%4s",memoryReference).replace(' ','0');
			}

		}
		else if(src1Address != null && src2Address == null && memoryReference != null && immediate == null)
		{
			if(source1Name.equalsIgnoreCase(destinationName) || source1Name.equalsIgnoreCase('[' + destinationName + ']'))
			{
				this.src1Address = destAddress;
			}
			else
			{
				src1Address = createAddress();
				this.src1Address = "0x" + String.format("%4s",src1Address).replace(' ','0');
			}
			if(source2Name.equalsIgnoreCase(destinationName) || source2Name.equalsIgnoreCase('[' + destinationName + ']'))
			{
				this.src2Address = destAddress;
				this.memoryReference = destAddress;
				this.source2 = destAddress;
			}
			else if(source2Name.equalsIgnoreCase(source1Name))
			{
				this.src2Address = src1Address;
			}
			else
			{
				this.src2Address = "0x" + String.format("%4s",memoryReference).replace(' ','0');
			}
		}
		else if(src1Address == null && src2Address != null && memoryReference != null && immediate == null)
		{
			if(source1Name.equalsIgnoreCase(destinationName) || source1Name.equalsIgnoreCase('[' + destinationName + ']'))
			{
				this.src1Address = destAddress;
				this.memoryReference = destAddress;
				this.source1 = destAddress;
			}
			else
			{
				this.src1Address = "0x" + String.format("%4s",memoryReference).replace(' ','0');
			}
			if(source2Name.equalsIgnoreCase(destinationName) || source2Name.equalsIgnoreCase('[' + destinationName + ']'))
			{
				this.src2Address = destAddress;
			}
			else if(source2Name.equalsIgnoreCase(source1Name))
			{
				this.src2Address = src1Address;
			}
			else
			{
				src2Address = createAddress();
				this.src2Address = "0x" + String.format("%4s",src2Address).replace(' ','0');
			}
		}
		else if(src2Address == null && memoryReference != null && immediate != null)
		{
			if(source1Name.equalsIgnoreCase(destinationName) || source1Name.equalsIgnoreCase('[' + destinationName + ']'))
			{
				this.src1Address = destAddress;
				this.memoryReference = destAddress;
				this.source1 = destAddress;
			}
			else
			{
				this.src1Address = "0x" + String.format("%4s",memoryReference).replace(' ','0');
			}
		}
		else if(src1Address == null && src2Address == null && memoryReference != null && immediate == null && !option.equals("Load"))
		{
			if(source1Name.equalsIgnoreCase(destinationName) || source1Name.equalsIgnoreCase('[' + destinationName + ']'))
			{
				this.src1Address = destAddress;
				this.memoryReference = destAddress;
				this.source1 = destAddress;
			}
			else
			{
				this.src1Address = "0x" + String.format("%4s",memoryReference).replace(' ','0');
			}

		}
		else if(src1Address != null && src2Address == null && memoryReference == null && immediate == null)
		{
			if(source1Name.equalsIgnoreCase(destinationName) || source1Name.equalsIgnoreCase('[' + destinationName + ']'))
			{
				this.src1Address = destAddress;
				this.memoryReference = destAddress;
				this.source1 = destAddress;
			}
			else
			{
				src1Address = createAddress();
				this.src1Address = "0x" + String.format("%4s",src1Address).replace(' ','0');
			}

		}
		else if(src1Address == null && src2Address == null && memoryReference != null && immediate == null && option.equals("Load"))
		{
			if(source1Name.equalsIgnoreCase(destinationName) || source1Name.equalsIgnoreCase('[' + destinationName + ']'))
			{
				this.src1Address = destAddress;
				this.memoryReference = destAddress;
				this.source1 = destAddress;
			}
			else
			{
				src1Address = createAddress();
				this.src1Address = "0x" + String.format("%4s",src1Address).replace(' ','0');
			}

		}
		else if(src1Address == null && src2Address == null && memoryReference != null && immediate == null && !option.equals("Store"))
		{
			if(source1Name.equalsIgnoreCase(destinationName) || source1Name.equalsIgnoreCase('[' + destinationName + ']'))
			{
				this.src1Address = destAddress;
				this.memoryReference = destAddress;
				this.source1 = destAddress;
			}
			else
			{
				this.src1Address = "0x" + String.format("%4s",memoryReference).replace(' ','0');
			}

		}
		else if(src1Address == null && src2Address == null && memoryReference == null && immediate != null && option.equals("Store"))
		{
			if(source1Name.equalsIgnoreCase(destinationName) || source1Name.equalsIgnoreCase('[' + destinationName + ']'))
			{
				this.src1Address = destAddress;
				this.memoryReference = destAddress;
				this.source1 = destAddress;
			}
			else
			{
				this.src1Address = "0x" + String.format("%4s",memoryReference).replace(' ','0');
			}

		}
		else if(src1Address == null && src2Address == null && memoryReference == null && immediate == null && option.equals("Call"))
		{
			this.destAddress = "0x" + String.format("%4s",memoryReference).replace(' ','0');

		}
	}

	private String createAddress()
	{
		 address = "";
		 for (int i = 0; i < 4; i++) 
		 {
			 address += hexNum.charAt(ran.nextInt(hexCount));   
		 }
		 return address;
		
	}
	private int compute(int num1, int num2)
	{
		String bin1 = "";
		String bin2 = "";
		String binResult = "";
		if(option.equals("Add"))
		{
			result = num1 + num2;
		}
		else if(option.equals("And"))
		{
			bin1 = Integer.toBinaryString(num1);
			bin2 = Integer.toBinaryString(num2);
			
			if(bin1.length() >= bin2.length())
			{
				bin2 = String.format("%" + bin1.length() + "s",bin2).replace(' ','0');
				for(int i = 0; i < bin1.length(); i++)
				{
					if(bin1.charAt(i) == '0' || bin2.charAt(i) == '0')
					{
						binResult += "0";
					}
					else
					{
						binResult += "1";
					}
					
				}
			}
			else
			{
				bin1 = String.format("%" + bin2.length() + "s",bin1).replace(' ','0');
				for(int i = 0; i < bin2.length(); i++)
				{
					if(bin2.charAt(i) == '0' || bin1.charAt(i) == '0')
					{
						binResult += "0";
					}
					else
					{
						binResult += "1";
					}
					
				}
			}
			result = Integer.parseInt(binResult,2);
		}
		else if(option.equals("Load"))
		{
			result = num1 + num2;
		}
		else if(option.equals("Store"))
		{
			result = num1 + num2;
		}
		return result;
	}
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "Next Stage");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
			
			if(count == 1)
			{
				stageOne();
			}
			else if(count == 2)
			{
				stageTwo();
			}
			else if (count == 3)
			{
				stageThree();
			}
			else if (count == 4)
			{
				stageFour();
			}
			else if (count == 5)
			{
				stageFive();
				nextStageButton.setVisible(false);
				resetButton.setVisible(true);
			}
			count++;
		}
	}
	
	private class NewInstructionListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			int choice = JOptionPane.showConfirmDialog(null, "Are you sure you want to enter a new instruction? \n" + "If so, the current DataPathModel window will be closed!","New Instruction Window", JOptionPane.YES_NO_OPTION);
			if(choice == 0)
			{
				frame.dispose();
				InstructionEntry frame = new InstructionEntry();
				frame.setVisible(true);
			}
		}
	}
	
	private class ResetListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			count = 1;
			addressCLabel.setText("");
			memDataLabel.setText("");
			cSelectLabel.setText("");
			registerCLabel.setText("");
			registerALabel.setText("");
			registerBLabel.setText("");
			registerRALabel.setText("");
			registerRBLabel.setText("");
			rf_WriteLabel.setText("");
			bSelectLabel.setText("");
			immediateLabel.setText("");
			aluInputA.setText("");
			aluInputB.setText("");
			aluOutput.setText("");
			registerRZLabel.setText("");
			registerRMLabel.setText("");
			returnAddressLabel.setText("");
			registerRYLabel.setText("");
			ySelectLabel.setText("");
			addressALabel.setText("");
			addressBLabel.setText("");
			resetButton.setVisible(false);
			nextStageButton.setVisible(true);
			stage2HighLabel.setVisible(false);
			stage3HighLabel.setVisible(false);
			stage4HighLabel.setVisible(false);
			stage5HighLabelPart1.setVisible(false);
			stage5HighLabelPart2.setVisible(false);
			addressCLabel.setBackground(Color.WHITE);
			registerCLabel.setBackground(Color.WHITE);
			rf_WriteLabel.setBackground(Color.WHITE);
			registerRYLabel.setBackground(Color.WHITE);
			cSelectLabel.setBackground(Color.WHITE);
			memDataLabel.setBackground(Color.WHITE);
		}
	}
}
class HighLight extends JLabel
{
	private Graphics g;
	private int width, height;
	public HighLight(int height, int width)
	{
		this.height = height;
		this.width =  width;
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		Color c = new Color(0f, 1f, 0f, .2f);
		g.setColor(c);
		g.fillRect(0, 0, height, width);
	}

	
}