import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLayeredPane;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import java.awt.Color;

import javax.swing.JButton;
import javax.swing.AbstractAction;

import java.awt.event.ActionEvent;
import java.util.Random;

import javax.swing.Action;

import java.awt.Button;
import java.awt.event.ActionListener;

import javax.swing.SwingConstants;

import java.awt.Font;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JPanel;
import java.awt.BorderLayout;

public class DataPathModel implements InstructionsInterface {
	private JFrame frame;
	protected String source1, source2, immediate, destination, memoryReference,
			src1Address, src2Address, destAddress, address, bSelect, cSelect,
			ySelect, computation, source1Name, source2Name, destinationName;
	protected int sourceAddress1, sourceAddress2, destinationAddress;
	protected int programCounter, pcSelect, pcEnabled;
	private JLabel addressBLabel;
	private final Action action = new SwingAction();
	private JLabel addressCLabel;
	private JLabel cSelectLabel;
	private JLabel registerCLabel;
	private JLabel registerALabel;
	private JLabel registerBLabel;
	private JLabel registerRALabel;
	private JLabel registerRBLabel;
	private JLabel rf_WriteLabel;
	private JLabel bSelectLabel;
	private JButton nextStageButton;
	private JLabel immediateLabel;
	private JLabel aluInputA;
	private JLabel aluInputB;
	private JLabel aluOutput;
	private JLabel registerRZLabel;
	private JLabel registerRMLabel;
	private JLabel returnAddressLabel;
	private JLabel registerRYLabel;
	private JLabel ySelectLabel;
	private Random ran = new Random();
	private JLabel addressALabel;
	private int count = 1;
	private Button resetButton;
	private int result = 0;
	private String option;
	private StringBuilder build = new StringBuilder();
	final String hexNum = "0123456789ABCDEF";
	final int hexCount = hexNum.length();
	private JMenuBar menuBar;
	private JMenu mnNewMenu;
	private JLabel stage2HighLabel;
	private JLabel stage3HighLabel;
	private JLabel stage4HighLabel;
	private JLabel stage5HighLabelPart1;
	private JLabel stage5HighLabelPart2;
	private JLabel memDataLabel;
	private JLabel memAddLabel;
	private String num;
	private String linkAddress;
	private JScrollPane scrollPane;



	public DataPathModel() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 695, 1051);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		frame.setLocation(dim.width / 2 - frame.getSize().width / 2, dim.height
				/ 2 - frame.getSize().height / 2);
		
		ImageIcon img = resizeImageIcon(new ImageIcon(this.getClass().getResource("Datapath.jpg")), 683, 999);
		scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 21, 687, 982);
		frame.getContentPane().add(scrollPane);
		
		JPanel panel = new JPanel();
		scrollPane.setViewportView(panel);
		
		JLayeredPane layeredPane = new JLayeredPane();
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addComponent(layeredPane, GroupLayout.DEFAULT_SIZE, 683, Short.MAX_VALUE)
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addComponent(layeredPane, GroupLayout.DEFAULT_SIZE, 999, Short.MAX_VALUE)
		);
		
		panel.setLayout(gl_panel);
		
				addressALabel = new JLabel("");
				addressALabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
				addressALabel.setHorizontalAlignment(SwingConstants.CENTER);
				addressALabel.setHorizontalTextPosition(SwingConstants.CENTER);
				addressALabel.setOpaque(true);
				addressALabel.setBackground(Color.WHITE);
				addressALabel.setBounds(141, 99, 103, 20);
				layeredPane.add(addressALabel);
		
		
		addressBLabel = new JLabel("");
		addressBLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		addressBLabel.setHorizontalAlignment(SwingConstants.CENTER);
		addressBLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		addressBLabel.setOpaque(true);
		addressBLabel.setBackground(Color.WHITE);
		addressBLabel.setBounds(141, 152, 103, 20);
		layeredPane.add(addressBLabel);
		
	

		nextStageButton = new JButton("Next Stage");
		nextStageButton.setAction(action);
		nextStageButton.setBackground(Color.LIGHT_GRAY);
		nextStageButton.setBounds(565, 965, 118, 34);
		layeredPane.add(nextStageButton);

		rf_WriteLabel = new JLabel("");
		rf_WriteLabel.setForeground(Color.BLACK);
		rf_WriteLabel.setVerticalAlignment(SwingConstants.BOTTOM);
		rf_WriteLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		rf_WriteLabel.setHorizontalAlignment(SwingConstants.CENTER);
		rf_WriteLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		rf_WriteLabel.setOpaque(true);
		rf_WriteLabel.setBackground(Color.WHITE);
		rf_WriteLabel.setBounds(380, 11, 73, 48);
		layeredPane.add(rf_WriteLabel);
		
	
		addressCLabel = new JLabel("");
		addressCLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		addressCLabel.setOpaque(true);
		addressCLabel.setForeground(Color.BLACK);
		addressCLabel.setBackground(Color.WHITE);
		addressCLabel.setBounds(386, 160, 97, 30);
		layeredPane.add(addressCLabel);

		cSelectLabel = new JLabel("");
		cSelectLabel.setVerticalAlignment(SwingConstants.TOP);
		cSelectLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		cSelectLabel.setHorizontalAlignment(SwingConstants.CENTER);
		cSelectLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		cSelectLabel.setBackground(Color.WHITE);
		cSelectLabel.setForeground(Color.BLACK);
		cSelectLabel.setOpaque(true);
		cSelectLabel.setBounds(556, 189, 89, 40);
		layeredPane.add(cSelectLabel);

		registerCLabel = new JLabel("");
		registerCLabel.setForeground(Color.BLACK);
		registerCLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		registerCLabel.setHorizontalAlignment(SwingConstants.CENTER);
		registerCLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		registerCLabel.setBackground(Color.WHITE);
		registerCLabel.setOpaque(true);
		registerCLabel.setBounds(249, 63, 118, 30);
		layeredPane.add(registerCLabel);
		

		registerALabel = new JLabel("");
		registerALabel.setForeground(Color.BLACK);
		registerALabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		registerALabel.setHorizontalAlignment(SwingConstants.CENTER);
		registerALabel.setHorizontalTextPosition(SwingConstants.CENTER);
		registerALabel.setOpaque(true);
		registerALabel.setBackground(Color.WHITE);
		registerALabel.setBounds(249, 191, 57, 30);
		layeredPane.add(registerALabel);

		registerBLabel = new JLabel("");
		registerBLabel.setForeground(Color.BLACK);
		registerBLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		registerBLabel.setHorizontalAlignment(SwingConstants.CENTER);
		registerBLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		registerBLabel.setBackground(Color.WHITE);
		registerBLabel.setOpaque(true);
		registerBLabel.setBounds(310, 189, 57, 35);
		layeredPane.add(registerBLabel);
		

		registerRALabel = new JLabel("");
		registerRALabel.setForeground(Color.BLACK);
		registerRALabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		registerRALabel.setHorizontalAlignment(SwingConstants.CENTER);
		registerRALabel.setHorizontalTextPosition(SwingConstants.CENTER);
		registerRALabel.setBackground(Color.WHITE);
		registerRALabel.setOpaque(true);
		registerRALabel.setBounds(173, 279, 118, 30);
		layeredPane.add(registerRALabel);
		

		registerRBLabel = new JLabel("");
		registerRBLabel.setOpaque(true);
		registerRBLabel.setForeground(Color.BLACK);
		registerRBLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		registerRBLabel.setHorizontalAlignment(SwingConstants.CENTER);
		registerRBLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		registerRBLabel.setBackground(Color.WHITE);
		registerRBLabel.setBounds(326, 279, 118, 30);
		layeredPane.add(registerRBLabel);
	
		

		bSelectLabel = new JLabel("");
		bSelectLabel.setForeground(Color.BLACK);
		bSelectLabel.setVerticalAlignment(SwingConstants.BOTTOM);
		bSelectLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		bSelectLabel.setHorizontalAlignment(SwingConstants.CENTER);
		bSelectLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		bSelectLabel.setOpaque(true);
		bSelectLabel.setBackground(Color.WHITE);
		bSelectLabel.setBounds(260, 351, 64, 35);
		layeredPane.add(bSelectLabel);

		immediateLabel = new JLabel("");
		immediateLabel.setForeground(Color.BLACK);
		immediateLabel.setVerticalAlignment(SwingConstants.BOTTOM);
		immediateLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		immediateLabel.setHorizontalAlignment(SwingConstants.CENTER);
		immediateLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		immediateLabel.setOpaque(true);
		immediateLabel.setBackground(Color.WHITE);		
		immediateLabel.setBounds(380, 351, 103, 35);
		layeredPane.add(immediateLabel);
		


		
		registerRZLabel = new JLabel("");
		registerRZLabel.setForeground(Color.BLACK);
		registerRZLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		registerRZLabel.setHorizontalAlignment(SwingConstants.CENTER);
		registerRZLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		registerRZLabel.setOpaque(true);
		registerRZLabel.setBackground(Color.WHITE);
		registerRZLabel.setBounds(249, 645, 118, 30);
		layeredPane.add(registerRZLabel);

		registerRMLabel = new JLabel("");
		registerRMLabel.setForeground(Color.BLACK);
		registerRMLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		registerRMLabel.setHorizontalAlignment(SwingConstants.CENTER);
		registerRMLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		registerRMLabel.setOpaque(true);
		registerRMLabel.setBackground(Color.WHITE);
		registerRMLabel.setBounds(464, 645, 118, 30);
		layeredPane.add(registerRMLabel);

		returnAddressLabel = new JLabel("");
		returnAddressLabel.setForeground(Color.BLACK);
		returnAddressLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		returnAddressLabel.setHorizontalAlignment(SwingConstants.CENTER);
		returnAddressLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		returnAddressLabel.setBackground(Color.WHITE);
		returnAddressLabel.setOpaque(true);
		returnAddressLabel.setBounds(417, 777, 118, 30);
		layeredPane.add(returnAddressLabel);

		ySelectLabel = new JLabel("");
		ySelectLabel.setForeground(Color.BLACK);
		ySelectLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		ySelectLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		ySelectLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		ySelectLabel.setOpaque(true);
		ySelectLabel.setBackground(Color.WHITE);
		ySelectLabel.setBounds(109, 837, 89, 30);
		layeredPane.add(ySelectLabel);

		registerRYLabel = new JLabel("");
		registerRYLabel.setForeground(Color.BLACK);
		registerRYLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		registerRYLabel.setHorizontalAlignment(SwingConstants.CENTER);
		registerRYLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		registerRYLabel.setBackground(Color.WHITE);
		registerRYLabel.setOpaque(true);
		registerRYLabel.setBounds(249, 912, 118, 30);
		layeredPane.add(registerRYLabel);

		stage2HighLabel = new HighLight(64,147);
		stage2HighLabel.setBounds(0, 128, 64, 147);
		layeredPane.add(stage2HighLabel);

		stage3HighLabel = new HighLight(64, 361);
		stage3HighLabel.setBounds(0, 276, 64, 361);
		layeredPane.add(stage3HighLabel);

		stage4HighLabel = new HighLight(64, 265);
		stage4HighLabel.setBounds(0, 639, 64, 265);
		layeredPane.add(stage4HighLabel);

		stage5HighLabelPart1 = new HighLight(64, 94);
		stage5HighLabelPart1.setBounds(0, 905, 64, 94);
		layeredPane.add(stage5HighLabelPart1);

		stage5HighLabelPart2 = new HighLight(64, 126);
		stage5HighLabelPart2.setBounds(0, 0, 64, 126);
		layeredPane.add(stage5HighLabelPart2);

		stage2HighLabel.setVisible(false);
		stage3HighLabel.setVisible(false);
		stage4HighLabel.setVisible(false);
		stage5HighLabelPart1.setVisible(false);
		stage5HighLabelPart2.setVisible(false);

		resetButton = new Button("Reset");
		resetButton.addActionListener(new ResetListener());
		resetButton.setBounds(568, 965, 115, 34);
		layeredPane.add(resetButton);

		memDataLabel = new JLabel("");
		memDataLabel.setForeground(Color.BLACK);
		memDataLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		memDataLabel.setHorizontalAlignment(SwingConstants.CENTER);
		memDataLabel.setBackground(Color.WHITE);
		memDataLabel.setOpaque(true);
		memDataLabel.setBounds(600, 729, 83, 58);
		layeredPane.add(memDataLabel);

		memAddLabel = new JLabel("");
		memAddLabel.setForeground(Color.BLACK);
		memAddLabel.setHorizontalAlignment(SwingConstants.CENTER);
		memAddLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		memAddLabel.setOpaque(true);
		memAddLabel.setBackground(Color.WHITE);
		memAddLabel.setBounds(600, 680, 83, 48);
		layeredPane.add(memAddLabel);
		
		aluInputA = new JLabel("");
		aluInputA.setBackground(Color.WHITE);
		aluInputA.setForeground(Color.BLACK);
		aluInputA.setFont(new Font("Times New Roman", Font.BOLD, 16));
		aluInputA.setHorizontalAlignment(SwingConstants.CENTER);
		aluInputA.setOpaque(true);
		aluInputA.setBounds(220, 516, 73, 30);
		layeredPane.add(aluInputA);
		
		aluInputB = new JLabel("");
		aluInputB.setBackground(Color.WHITE);
		aluInputB.setOpaque(true);
		aluInputB.setHorizontalAlignment(SwingConstants.CENTER);
		aluInputB.setForeground(Color.BLACK);
		aluInputB.setFont(new Font("Times New Roman", Font.BOLD, 16));
		aluInputB.setBounds(326, 516, 73, 30);
		layeredPane.add(aluInputB);
		
		aluOutput = new JLabel("");
		aluOutput.setBackground(Color.WHITE);
		aluOutput.setOpaque(true);
		aluOutput.setForeground(Color.BLACK);
		aluOutput.setFont(new Font("Times New Roman", Font.BOLD, 16));
		aluOutput.setHorizontalAlignment(SwingConstants.CENTER);
		aluOutput.setBounds(249, 578, 118, 30);
		layeredPane.add(aluOutput);

		

		
		JLabel dataPathPicture = new JLabel(img);
		dataPathPicture.setBounds(0, 0, 683, 999);
		layeredPane.add(dataPathPicture);
		
		menuBar = new JMenuBar();

		mnNewMenu = new JMenu("New menu");
		JMenuItem mitem = new JMenuItem("New Instruction Entry");
		mitem.addActionListener(new NewInstructionListener());
		mnNewMenu.add(mitem);
		menuBar.add(mnNewMenu);

		frame.getContentPane().add(menuBar, BorderLayout.NORTH);

		

		frame.setVisible(true);
	}

	public void stageOne() {
		if(!option.equals("Store")){
		if (source1Name != null
				&& (source1Name.equalsIgnoreCase(destinationName) || source1Name
						.equalsIgnoreCase('[' + destinationName + ']'))) {
			addressALabel.setText("0x" + src1Address);
			addressALabel.setBackground(Color.YELLOW);
		} else if (src1Address != null) {
			addressALabel.setText(src1Address);
			addressALabel.setBackground(Color.YELLOW);
		} else {
			addressALabel.setText(src1Address);
		}
		if (source2Name != null
				&& (source2Name.equalsIgnoreCase(destinationName) || source2Name
						.equalsIgnoreCase('[' + destinationName + ']'))) {
			addressBLabel.setText("0x" + src2Address);
			addressBLabel.setBackground(Color.YELLOW);
		} else if (src2Address != null) {
			addressBLabel.setText(src2Address);
			addressBLabel.setBackground(Color.YELLOW);
		} else if (src1Address == null && src2Address == null
				&& destAddress != null) {
			addressALabel.setText(destAddress);
			addressALabel.setBackground(Color.YELLOW);
		} else {
			addressBLabel.setText(src2Address);
		}
		}
		else
		{
			addressALabel.setText("0x" + destAddress);
			addressALabel.setBackground(Color.YELLOW);
			addressBLabel.setText(src1Address);
			addressBLabel.setBackground(Color.YELLOW);
		}
	}

	public void stageTwo() {
		addressALabel.setBackground(Color.WHITE);
		addressBLabel.setBackground(Color.WHITE);
		if(!option.equals("Store")){
		if (source1Name != null) {
			registerALabel.setText(source1Name.toUpperCase());
			registerALabel.setBackground(Color.YELLOW);
		}
		if (source2Name != null) {
			registerBLabel.setText(source2Name.toUpperCase());
			registerBLabel.setBackground(Color.YELLOW);
		}
		if (source1Name == null && source2Name == null
				&& destinationName != null) {
			registerALabel.setText(destinationName.toUpperCase());
			registerALabel.setBackground(Color.YELLOW);
		}}
		else
		{
			registerALabel.setText(destinationName.toUpperCase());
			registerALabel.setBackground(Color.YELLOW);
			registerBLabel.setText(source1Name.toUpperCase());
			registerBLabel.setBackground(Color.YELLOW);
		}
		stage2HighLabel.setVisible(true);
		stage3HighLabel.setVisible(false);
		stage4HighLabel.setVisible(false);
		stage5HighLabelPart1.setVisible(false);
		stage5HighLabelPart2.setVisible(false);

	}

	public void stageThree() {
		registerALabel.setBackground(Color.WHITE);
		registerBLabel.setBackground(Color.WHITE);
		build.setLength(0);
		if (!option.equals("Call")) {

			if (option.equals("Add")) {
				if (immediate == null && memoryReference != null
						&& source1.equals(memoryReference)) {
					result = compute(Integer.parseInt(source2),
							Integer.parseInt(source1, 16));
					this.computation = "0x"
							+ String.format("%4s", Integer.toHexString(result)
									.toUpperCase().replace(' ', '0'));
				} else if (immediate == null && memoryReference != null
						&& source2.equals(memoryReference)) {
					result = compute(Integer.parseInt(source1),
							Integer.parseInt(source2, 16));
					this.computation = "0x"
							+ String.format("%4s", Integer.toHexString(result)
									.toUpperCase().replace(' ', '0'));
				} else if (immediate == null && memoryReference == null
						&& source1 != null && source2 != null) {
					result = compute(Integer.parseInt(source1),
							Integer.parseInt(source2));
					this.computation = Integer.toString(result);
				} else if (immediate != null && source2 == null
						&& memoryReference == null) {
					result = compute(Integer.parseInt(immediate),
							Integer.parseInt(source1));
					this.computation = Integer.toString(result);
				} else if (immediate != null && memoryReference == null) {
					result = compute(Integer.parseInt(immediate),
							Integer.parseInt(source1));
					this.computation = "0x"
							+ String.format("%4s", Integer.toHexString(result)
									.toUpperCase().replace(' ', '0'));
				} else if (immediate != null && memoryReference != null) {
					result = compute(Integer.parseInt(immediate),
							Integer.parseInt(source1, 16));
					this.computation = "0x"
							+ String.format("%4s", Integer.toHexString(result)
									.toUpperCase().replace(' ', '0'));
				}
				if (source1.equals(memoryReference) && source2 != null
						&& immediate == null) {
					registerRALabel.setText("0x" + source1.toUpperCase());
					registerRALabel.setBackground(Color.YELLOW);
					aluInputA.setText("0x" + source1.toUpperCase());
					aluInputA.setBackground(Color.YELLOW);
					registerRBLabel.setText(source2);
					registerRBLabel.setBackground(Color.YELLOW);
					aluInputB.setText(source2);
					aluInputB.setBackground(Color.YELLOW);
				}
				if (source1 != null && source2 != null
						&& source2.equals(memoryReference) && immediate == null) {
					registerRALabel.setText(source1);
					aluInputA.setText(source1);
					registerRBLabel.setText("0x" + source2.toUpperCase());
					aluInputB.setText("0x" + source2.toUpperCase());
					registerRALabel.setBackground(Color.YELLOW);
					aluInputA.setBackground(Color.YELLOW);
					registerRBLabel.setBackground(Color.YELLOW);
					aluInputB.setBackground(Color.YELLOW);
				}
				if (source2 != null && source1 != null
						&& memoryReference == null && immediate == null) {
					registerRALabel.setText(source1);
					aluInputA.setText(source1);
					registerRBLabel.setText(source2);
					aluInputB.setText(source2);
					registerRALabel.setBackground(Color.YELLOW);
					aluInputA.setBackground(Color.YELLOW);
					registerRBLabel.setBackground(Color.YELLOW);
					aluInputB.setBackground(Color.YELLOW);
				} else if (immediate != null && memoryReference != null) {
					registerRALabel.setText("0x" + source1.toUpperCase());
					aluInputA.setText("0x" + source1.toUpperCase());
					immediateLabel.setBackground(Color.YELLOW);
				}
				if (source1 != null && memoryReference == null
						&& immediate != null) {
					registerRALabel.setText(source1);
					aluInputA.setText(source1);
					immediateLabel.setBackground(Color.YELLOW);
				}
				if (source2 == null && immediate != null) {
					aluInputB.setText(immediate);
					aluInputB.setBackground(Color.YELLOW);
				}
				immediateLabel.setText(immediate);
				bSelectLabel.setText(bSelect);
				aluOutput.setText(computation);
				bSelectLabel.setBackground(Color.YELLOW);
				aluOutput.setBackground(Color.YELLOW);
			} else if (option.equals("And")) {
				if (immediate == null && memoryReference != null
						&& source1.equals(memoryReference)) {
					result = compute(Integer.parseInt(source2),
							Integer.parseInt(source1, 16));
					build.append(Integer.toHexString(result));
					while (build.length() < 4) {
						build.insert(0, '0');
					}
					this.computation = "0x" + build.toString().toUpperCase();
				} else if (immediate == null && memoryReference != null
						&& source2.equals(memoryReference)) {
					result = compute(Integer.parseInt(source1),
							Integer.parseInt(source2, 16));
					build.append(Integer.toHexString(result));
					while (build.length() < 4) {
						build.insert(0, '0');
					}
					this.computation = "0x" + build.toString().toUpperCase();
				} else if (immediate == null && memoryReference == null
						&& source1 != null && source2 != null) {
					result = compute(Integer.parseInt(source1),
							Integer.parseInt(source2));
					this.computation = Integer.toString(result);
				} else if (immediate != null && source2 == null
						&& memoryReference == null) {
					result = compute(Integer.parseInt(immediate),
							Integer.parseInt(source1));
					this.computation = Integer.toString(result);
				} else if (immediate != null && memoryReference == null) {
					result = compute(Integer.parseInt(immediate),
							Integer.parseInt(source1));
					build.append(Integer.toHexString(result));
					while (build.length() < 4) {
						build.insert(0, '0');
					}
					this.computation = "0x" + build.toString().toUpperCase();
				} else if (immediate != null && memoryReference != null) {
					result = compute(Integer.parseInt(immediate),
							Integer.parseInt(source1, 16));
					build.append(Integer.toHexString(result));
					while (build.length() < 4) {
						build.insert(0, '0');
					}
					this.computation = "0x" + build.toString().toUpperCase();

				}
				if (source1.equals(memoryReference) && source2 != null
						&& immediate == null) {
					registerRALabel.setText("0x"
							+ String.format("%4s", source1.toUpperCase())
									.replace(' ', '0'));
					aluInputA.setText("0x"
							+ String.format("%4s", source1.toUpperCase())
									.replace(' ', '0'));
					registerRBLabel.setText(source2);
					aluInputB.setText(source2);
					registerRALabel.setBackground(Color.YELLOW);
					aluInputA.setBackground(Color.YELLOW);
					registerRBLabel.setBackground(Color.YELLOW);
					aluInputB.setBackground(Color.YELLOW);

				}
				if (source1 != null && source2 != null
						&& source2.equals(memoryReference) && immediate == null) {
					registerRALabel.setText(source1);
					aluInputA.setText(source1);
					registerRBLabel.setText("0x"
							+ String.format("%4s", source2.toUpperCase())
									.replace(' ', '0'));
					aluInputB.setText("0x"
							+ String.format("%4s", source2.toUpperCase())
									.replace(' ', '0'));
					registerRALabel.setBackground(Color.YELLOW);
					aluInputA.setBackground(Color.YELLOW);
					registerRBLabel.setBackground(Color.YELLOW);
					aluInputB.setBackground(Color.YELLOW);
				}
				if (source2 != null && source1 != null
						&& memoryReference == null && immediate == null) {
					registerRALabel.setText(source1);
					aluInputA.setText(source1);
					registerRBLabel.setText(source2);
					aluInputB.setText(source2);
					registerRALabel.setBackground(Color.YELLOW);
					aluInputA.setBackground(Color.YELLOW);
					registerRBLabel.setBackground(Color.YELLOW);
					aluInputB.setBackground(Color.YELLOW);
				} else if (immediate != null && memoryReference != null) {
					registerRALabel.setText("0x"
							+ String.format("%4s", source1.toUpperCase())
									.replace(' ', '0'));
					aluInputA.setText("0x"
							+ String.format("%4s", source1.toUpperCase())
									.replace(' ', '0'));
					registerRALabel.setBackground(Color.YELLOW);
					aluInputA.setBackground(Color.YELLOW);
					immediateLabel.setBackground(Color.YELLOW);
				}
				if (source1 != null && memoryReference == null
						&& immediate != null) {
					registerRALabel.setText(source1);
					aluInputA.setText(source1);
					registerRALabel.setBackground(Color.YELLOW);
					aluInputA.setBackground(Color.YELLOW);
					immediateLabel.setBackground(Color.YELLOW);
				}
				if (source2 == null && immediate != null) {
					aluInputB.setText(immediate);
					aluInputB.setBackground(Color.YELLOW);
				}
				immediateLabel.setText(immediate);
				bSelectLabel.setText(bSelect);
				aluOutput.setText(computation);
				bSelectLabel.setBackground(Color.YELLOW);
				aluOutput.setBackground(Color.YELLOW);
			} else if (option.equals("Load")) {
				if (source1 != null && memoryReference == null) {
					registerRALabel.setText(source1);
					aluInputA.setText(source1);
					registerRALabel.setBackground(Color.YELLOW);
					aluInputA.setBackground(Color.YELLOW);
					aluOutput.setText(source1);
					aluOutput.setBackground(Color.YELLOW);

				} else if (source1 != null && memoryReference != null) {
					registerRALabel.setText("0x"
							+ String.format("%4s", source1.toUpperCase())
									.replace(' ', '0'));
					aluInputA.setText("0x"
							+ String.format("%4s", source1.toUpperCase())
									.replace(' ', '0'));
					registerRALabel.setBackground(Color.YELLOW);
					aluInputA.setBackground(Color.YELLOW);
					if (immediate != null) {
						immediateLabel.setText(immediate);
						immediateLabel.setBackground(Color.YELLOW);
						aluInputB.setText(immediate);
						aluInputB.setBackground(Color.YELLOW);
						result = compute(Integer.parseInt(source1, 16),
								Integer.parseInt(immediate));
						build.append(Integer.toHexString(result));
						while (build.length() < 4) {
							build.insert(0, '0');
						}
						this.computation = "0x" + build.toString().toUpperCase();
						aluOutput.setText(computation);
						aluOutput.setBackground(Color.YELLOW);
					} else {
						aluOutput.setText("0x"
								+ String.format("%4s", source1.toUpperCase())
										.replace(' ', '0'));
						aluOutput.setBackground(Color.YELLOW);
					}
				}
				bSelectLabel.setText(bSelect);
				bSelectLabel.setBackground(Color.YELLOW);

			}
		 else if (option.equals("Store")) {
			if (source1 != null && memoryReference != null) {
				registerRALabel.setText("0x"
						+ String.format("%4s", destAddress.toUpperCase()).replace(
								' ', '0'));
				aluInputA.setText("0x"
						+ String.format("%4s", destAddress.toUpperCase()).replace(
								' ', '0'));
				registerRALabel.setBackground(Color.YELLOW);
				registerRBLabel.setText(source1);
				registerRBLabel.setBackground(Color.YELLOW);
				aluInputA.setBackground(Color.YELLOW);
				if (immediate != null) {
					immediateLabel.setText(immediate);
					immediateLabel.setBackground(Color.YELLOW);
					aluInputB.setText(immediate);
					aluInputB.setBackground(Color.YELLOW);
					result = compute(Integer.parseInt(destAddress, 16),
							Integer.parseInt(immediate));
					build.append(Integer.toHexString(result));
					while (build.length() < 4) {
						build.insert(0, '0');
					}
					this.computation = "0x" + build.toString().toUpperCase();
					aluOutput.setText(computation);
					aluOutput.setBackground(Color.YELLOW);
					registerRZLabel.setText(computation);
					registerRZLabel.setBackground(Color.YELLOW);
					registerRMLabel.setText(source1);
					registerRMLabel.setBackground(Color.YELLOW);
				} else {
					aluOutput.setText("0x"
							+ String.format("%4s", destAddress.toUpperCase())
									.replace(' ', '0'));
					aluOutput.setBackground(Color.YELLOW);
				}
			}
			bSelectLabel.setText(bSelect);
			bSelectLabel.setBackground(Color.YELLOW);

		}
		}
		if (option.equals("Call")) {
			registerRALabel.setText(destAddress);
			registerRALabel.setBackground(Color.YELLOW);
			programCounter = ran.nextInt(9999) + 1;
			pcSelect = 0;
			pcEnabled = 1;

			try {
				RoutineCall frame = new RoutineCall(destAddress,
						programCounter, pcSelect, pcEnabled, this);
				frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		stage2HighLabel.setVisible(false);
		stage3HighLabel.setVisible(true);
		stage4HighLabel.setVisible(false);
		stage5HighLabelPart1.setVisible(false);
		stage5HighLabelPart2.setVisible(false);

	}

	public void stageFour() {
		registerRALabel.setBackground(Color.WHITE);
		aluInputA.setBackground(Color.WHITE);
		registerRBLabel.setBackground(Color.WHITE);
		aluInputB.setBackground(Color.WHITE);
		immediateLabel.setBackground(Color.WHITE);
		bSelectLabel.setBackground(Color.WHITE);
		aluOutput.setBackground(Color.WHITE);
		registerRZLabel.setBackground(Color.WHITE);
		registerRMLabel.setBackground(Color.WHITE);
		num = Integer.toString(ran.nextInt(9999) + 1);
		if (!option.equals("Call")) {
			if (option.equals("Store") && memoryReference != null) {
				memAddLabel.setText(computation);
				memAddLabel.setBackground(Color.YELLOW);
				memDataLabel.setText(source1.toUpperCase());
				memDataLabel.setBackground(Color.YELLOW);
			} else if (option.equals("Load") && memoryReference != null
					&& immediate == null) {
				registerRZLabel.setText(source1);
				registerRZLabel.setBackground(Color.YELLOW);
				memDataLabel.setText(num);
				memDataLabel.setBackground(Color.YELLOW);
			} else if (option.equals("Load") && memoryReference == null
					&& immediate == null) {
				registerRZLabel.setText(source1);
				registerRZLabel.setBackground(Color.YELLOW);
				memDataLabel.setText(num);
				memDataLabel.setBackground(Color.YELLOW);
			} else if (option.equals("Load") && memoryReference != null
					&& immediate != null) {
				registerRZLabel.setText(computation);
				registerRZLabel.setBackground(Color.YELLOW);
				memDataLabel.setText(num);
				memDataLabel.setBackground(Color.YELLOW);
			}
			else {
				registerRZLabel.setText(computation);
				registerRZLabel.setBackground(Color.YELLOW);
			}

			if (!option.equals("Store")) {
				ySelectLabel.setText(ySelect);
				ySelectLabel.setBackground(Color.YELLOW);
			}
		}
		if (option.equals("Call")) {
			returnAddressLabel.setText(destAddress);
			returnAddressLabel.setBackground(Color.YELLOW);
			ySelectLabel.setText(ySelect);
			ySelectLabel.setBackground(Color.YELLOW);
		}
		
		stage2HighLabel.setVisible(false);
		stage3HighLabel.setVisible(false);
		stage4HighLabel.setVisible(true);
		stage5HighLabelPart1.setVisible(false);
		stage5HighLabelPart2.setVisible(false);
	}

	public void disableEnableNextStage(boolean set) {
		nextStageButton.setEnabled(set);
	}

	public void stageFive() {
		registerRZLabel.setBackground(Color.WHITE);
		memAddLabel.setBackground(Color.WHITE);
		memDataLabel.setBackground(Color.WHITE);
		registerRMLabel.setBackground(Color.WHITE);
		ySelectLabel.setBackground(Color.WHITE);
		returnAddressLabel.setBackground(Color.WHITE);
		if (!option.equals("Store")) {
			addressCLabel.setText("0x" + destAddress);
			registerCLabel.setText(destinationName.toUpperCase());
			rf_WriteLabel.setText("1");

			if (ySelect.equals("00")) {
				registerRYLabel.setText(num);
				addressCLabel.setText("0x" + destAddress);
				registerCLabel.setText(destinationName.toUpperCase());
				rf_WriteLabel.setText("1");
				registerRYLabel.setText(computation);
				addressCLabel.setBackground(Color.YELLOW);
				registerCLabel.setBackground(Color.YELLOW);
				rf_WriteLabel.setBackground(Color.YELLOW);
				registerRYLabel.setBackground(Color.YELLOW);
				cSelectLabel.setBackground(Color.YELLOW);
			}
			if (ySelect.equals("01")) {
				registerRYLabel.setText(num);
				addressCLabel.setText("0x" + destAddress);
				registerCLabel.setText(destinationName.toUpperCase());
				rf_WriteLabel.setText("1");		
				registerRYLabel.setText(num);
				addressCLabel.setBackground(Color.YELLOW);
				registerCLabel.setBackground(Color.YELLOW);
				rf_WriteLabel.setBackground(Color.YELLOW);
				registerRYLabel.setBackground(Color.YELLOW);
				cSelectLabel.setBackground(Color.YELLOW);
			} else if (ySelect.equals("10")) {
				addressCLabel.setText("0x" + linkAddress);
				registerRYLabel.setText(destAddress);
				registerCLabel.setText("LINK");
				rf_WriteLabel.setText("1");
				addressCLabel.setBackground(Color.YELLOW);
				registerCLabel.setBackground(Color.YELLOW);
				rf_WriteLabel.setBackground(Color.YELLOW);
				registerRYLabel.setBackground(Color.YELLOW);
				cSelectLabel.setBackground(Color.YELLOW);
			}

			cSelectLabel.setText(cSelect);

			
		}
		stage2HighLabel.setVisible(false);
		stage3HighLabel.setVisible(false);
		stage4HighLabel.setVisible(false);
		stage5HighLabelPart1.setVisible(true);
		stage5HighLabelPart2.setVisible(true);
	}

	@Override
	public void AddTwoOperands(String destinationName, String source1Name,
			String source2Name, String source1, String source2) {
		// TODO Auto-generated method stub
		this.destinationName = destinationName;
		this.source1Name = source1Name;
		this.source2Name = source2Name;
		this.source1 = source1;
		this.src1Address = source1;
		this.source2 = source2;
		this.src2Address = source2;
		this.bSelect = "00";
		this.ySelect = "00";
		this.cSelect = "01";
		option = "Add";
		setAddreses();
	}

	@Override
	public void AddOneOperandsrc1Mem(String destinationName,
			String source1Name, String source2Name, String source2,
			String memRef) {
		this.destinationName = destinationName;
		this.source1Name = source1Name;
		this.source2Name = source2Name;
		this.source2 = source2;
		this.src2Address = source2;
		this.source1 = memRef;
		this.src1Address = null;
		this.memoryReference = memRef;
		this.bSelect = "00";
		this.ySelect = "00";
		this.cSelect = "01";
		option = "Add";
		setAddreses();
	}

	@Override
	public void AddOneOperandsrc2Mem(String destinationName,
			String source1Name, String source2Name, String source1,
			String memRef) {
		this.destinationName = destinationName;
		this.source1Name = source1Name;
		this.source2Name = source2Name;
		this.source1 = source1;
		this.src1Address = source1;
		this.src2Address = null;
		this.source2 = memRef;
		this.memoryReference = memRef;
		this.bSelect = "00";
		this.ySelect = "00";
		this.cSelect = "01";
		option = "Add";
		setAddreses();
	}

	@Override
	public void AddOneOperandImm(String destinationName, String source1Name,
			String source1, int immediate) {
		// TODO Auto-generated method stub
		this.destinationName = destinationName;
		this.source1Name = source1Name;
		this.source1 = source1;
		this.src1Address = source1;
		this.source2 = null;
		this.immediate = Integer.toString(immediate);
		this.bSelect = "01";
		this.ySelect = "00";
		this.cSelect = "01";
		option = "Add";
		setAddreses();
	}

	@Override
	public void AddMemandImm(String destinationName, String source1Name,
			String memRef, int immediate) {
		this.destinationName = destinationName;
		this.source1Name = source1Name;
		this.memoryReference = memRef;
		this.immediate = Integer.toString(immediate);
		this.source1 = memRef;
		this.src1Address = null;
		this.src2Address = null;
		this.bSelect = "01";
		this.ySelect = "00";
		this.cSelect = "01";
		option = "Add";
		setAddreses();
	}

	@Override
	public void AndTwoOperands(String destinationName, String source1Name,
			String source2Name, String source1, String source2) {
		// TODO Auto-generated method stub
		this.destinationName = destinationName;
		this.source1Name = source1Name;
		this.source2Name = source2Name;
		this.source1 = source1;
		this.src1Address = source1;
		this.source2 = source2;
		this.src2Address = source2;
		this.bSelect = "00";
		this.ySelect = "00";
		this.cSelect = "01";
		option = "And";
		setAddreses();
	}

	@Override
	public void AndOneOperandsrc1Mem(String destinationName,
			String source1Name, String source2Name, String source2,
			String memRef) {
		this.destinationName = destinationName;
		this.source1Name = source1Name;
		this.source2Name = source2Name;
		this.source2 = source2;
		this.src2Address = source2;
		this.source1 = memRef;
		this.src1Address = null;
		this.memoryReference = memRef;
		this.bSelect = "00";
		this.ySelect = "00";
		this.cSelect = "01";
		option = "And";
		setAddreses();
	}

	@Override
	public void AndOneOperandsrc2Mem(String destinationName,
			String source1Name, String source2Name, String source1,
			String memRef) {
		this.destinationName = destinationName;
		this.source1Name = source1Name;
		this.source2Name = source2Name;
		this.source1 = source1;
		this.src1Address = source1;
		this.src2Address = null;
		this.source2 = memRef;
		this.memoryReference = memRef;
		this.bSelect = "00";
		this.ySelect = "00";
		this.cSelect = "01";
		option = "And";
		setAddreses();
	}

	@Override
	public void AndOneOperandImm(String destinationName, String source1Name,
			String source1, int immediate) {
		// TODO Auto-generated method stub
		this.destinationName = destinationName;
		this.source1Name = source1Name;
		this.source1 = source1;
		this.src1Address = source1;
		this.source2 = null;
		this.immediate = Integer.toString(immediate);
		this.bSelect = "01";
		this.ySelect = "00";
		this.cSelect = "01";
		option = "And";
		setAddreses();
	}

	@Override
	public void AndMemandImm(String destinationName, String source1Name,
			String memRef, int immediate) {
		this.destinationName = destinationName;
		this.source1Name = source1Name;
		this.memoryReference = memRef;
		this.immediate = Integer.toString(immediate);
		this.source1 = memRef;
		this.src1Address = null;
		this.src2Address = null;
		this.bSelect = "01";
		this.ySelect = "00";
		this.cSelect = "01";
		option = "And";
		setAddreses();
	}

	@Override
	public void LoadOperand(String destinationName, String sourceName,
			String source) {
		this.destinationName = destinationName;
		this.source1Name = sourceName;
		this.source1 = source;
		this.src1Address = source;
		this.bSelect = "00";
		this.ySelect = "01";
		this.cSelect = "00";
		option = "Load";
		setAddreses();
	}

	@Override
	public void LoadMemRef(String destinationName, String sourceName,
			String memRef, int immediate) {
		source1Name = "";
		for (int i = 0; i < sourceName.length(); i++) {
			if (Character.isLetter(sourceName.charAt(i))) {
				while (Character.isLetterOrDigit(sourceName.charAt(i))) {
					this.source1Name += sourceName.charAt(i);
					i++;
				}

			}
		}

		this.destinationName = destinationName;
		this.memoryReference = memRef;
		this.source1 = memRef;
		this.src1Address = null;
		this.immediate = Integer.toString(immediate);
		if (this.immediate != null && !this.immediate.isEmpty()) {
			this.bSelect = "01";
		} else {
			this.bSelect = "00";
		}
		this.ySelect = "01";
		this.cSelect = "01";
		option = "Load";
		setAddreses();
	}

	@Override
	public void StoreMemRef(String destinationName, String sourceName,
			String source, int immediate) {
		source1Name = "";
		for (int i = 0; i < sourceName.length(); i++) {
			if (Character.isLetter(sourceName.charAt(i))) {
				while (Character.isLetterOrDigit(sourceName.charAt(i))) {
					this.source1Name += sourceName.charAt(i);
					i++;
				}
			}
		}

		this.destinationName = destinationName;
		this.memoryReference = source;
		this.source1 = source;
		this.src1Address = null;
		this.immediate = Integer.toString(immediate);
		if (this.immediate != null && !this.immediate.isEmpty()) {
			this.bSelect = "01";
		} else {
			this.bSelect = "00";
		}
		this.ySelect = "01";
		this.cSelect = "01";
		option = "Store";
		setAddreses();
	}

	@Override
	public void Call(String destinationName, String memRef) {

		this.destinationName = destinationName.toUpperCase();
		this.memoryReference = "0x" + memRef.toUpperCase();
		this.destAddress = "0x" + memRef.toUpperCase();
		option = "Call";
		this.ySelect = "10";
		this.cSelect = "10";
		setAddreses();
	}

	@Override
	public void AndOneOperandImm(String destination, String source1,
			int immediate) {
		// TODO Auto-generated method stub
		this.source1 = source1;
		this.source2 = null;
		setAddreses();
	}

	private void setAddreses() {
		if (!option.equals("Call")) {
			destAddress = createAddress();
			this.destAddress = String.format("%4s", destAddress).replace(' ',
					'0');
		
		if (src1Address != null && src2Address != null
				&& memoryReference == null && immediate == null) {
			if (source1Name.equalsIgnoreCase(destinationName)
					|| source1Name
							.equalsIgnoreCase('[' + destinationName + ']')) {
				this.src1Address = destAddress;
			} else {
				src1Address = createAddress();
				this.src1Address = "0x" + src1Address;
			}
			if (source2Name.equals(destinationName)
					|| source2Name
							.equalsIgnoreCase('[' + destinationName + ']')) {
				this.src2Address = destAddress;
			} else if (source2Name.equals(source1Name)) {
				this.src2Address = src1Address;
			} else {
				src2Address = createAddress();
				while (src1Address == src2Address) {
					src2Address = createAddress();
				}

				this.src2Address = "0x" + src2Address;
			}

		} else if (src1Address != null && src2Address == null
				&& memoryReference == null && immediate != null) {
			if (source1Name.equalsIgnoreCase(destinationName)
					|| source1Name
							.equalsIgnoreCase('[' + destinationName + ']')) {
				this.src1Address = destAddress;
			} else {
				src1Address = createAddress();
				this.src1Address = "0x" + src1Address;
			}
		} else if (src1Address == null && src2Address == null
				&& memoryReference != null && immediate != null) {
			if (source1Name.equalsIgnoreCase(destinationName)
					|| source1Name
							.equalsIgnoreCase('[' + destinationName + ']')) {
				this.src1Address = destAddress;
				this.memoryReference = destAddress;
				this.source1 = destAddress;
			} else {
				this.src1Address = "0x"
						+ String.format("%4s", memoryReference).replace(' ',
								'0');
			}

		} else if (src1Address != null && src2Address == null
				&& memoryReference != null && immediate == null) {
			if (source1Name.equalsIgnoreCase(destinationName)
					|| source1Name
							.equalsIgnoreCase('[' + destinationName + ']')) {
				this.src1Address = destAddress;
			} else {
				src1Address = createAddress();
				this.src1Address = "0x"
						+ String.format("%4s", src1Address).replace(' ', '0');
			}
			if (source2Name.equalsIgnoreCase(destinationName)
					|| source2Name
							.equalsIgnoreCase('[' + destinationName + ']')) {
				this.src2Address = destAddress;
				this.memoryReference = destAddress;
				this.source2 = destAddress;
			} else if (source2Name.equalsIgnoreCase(source1Name)) {
				this.src2Address = src1Address;
			} else {
				this.src2Address = "0x"
						+ String.format("%4s", memoryReference).replace(' ',
								'0');
			}
		} else if (src1Address == null && src2Address != null
				&& memoryReference != null && immediate == null) {
			if (source1Name.equalsIgnoreCase(destinationName)
					|| source1Name
							.equalsIgnoreCase('[' + destinationName + ']')) {
				this.src1Address = destAddress;
				this.memoryReference = destAddress;
				this.source1 = destAddress;
			} else {
				this.src1Address = "0x"
						+ String.format("%4s", memoryReference).replace(' ',
								'0');
			}
			if (source2Name.equalsIgnoreCase(destinationName)
					|| source2Name
							.equalsIgnoreCase('[' + destinationName + ']')) {
				this.src2Address = destAddress;
			} else if (source2Name.equalsIgnoreCase(source1Name)) {
				this.src2Address = src1Address;
			} else {
				src2Address = createAddress();
				this.src2Address = "0x"
						+ String.format("%4s", src2Address).replace(' ', '0');
			}
		} else if (src2Address == null && memoryReference != null
				&& immediate != null) {
			if (source1Name.equalsIgnoreCase(destinationName)
					|| source1Name
							.equalsIgnoreCase('[' + destinationName + ']')) {
				this.src1Address = destAddress;
				this.memoryReference = destAddress;
				this.source1 = destAddress;
			} else {
				this.src1Address = "0x"
						+ String.format("%4s", memoryReference).replace(' ',
								'0');
			}
		} else if (src1Address == null && src2Address == null
				&& memoryReference != null && immediate == null
				&& !option.equals("Load")) {
			if (source1Name.equalsIgnoreCase(destinationName)
					|| source1Name
							.equalsIgnoreCase('[' + destinationName + ']')) {
				this.src1Address = destAddress;
				this.memoryReference = destAddress;
				this.source1 = destAddress;
			} else {
				this.src1Address = "0x"
						+ String.format("%4s", memoryReference).replace(' ',
								'0');
			}

		} else if (src1Address != null && src2Address == null
				&& memoryReference == null && immediate == null) {
			if (source1Name.equalsIgnoreCase(destinationName)
					|| source1Name
							.equalsIgnoreCase('[' + destinationName + ']')) {
				this.src1Address = destAddress;
				this.memoryReference = destAddress;
				this.source1 = destAddress;
			} else {
				src1Address = createAddress();
				this.src1Address = "0x"
						+ String.format("%4s", src1Address).replace(' ', '0');
			}

		} else if (src1Address == null && src2Address == null
				&& memoryReference != null && immediate == null
				&& option.equals("Load")) {
			if (source1Name.equalsIgnoreCase(destinationName)
					|| source1Name
							.equalsIgnoreCase('[' + destinationName + ']')) {
				this.src1Address = destAddress;
				this.memoryReference = destAddress;
				this.source1 = destAddress;
			} else {
				src1Address = createAddress();
				this.src1Address = "0x"
						+ String.format("%4s", src1Address).replace(' ', '0');
			}

		} else if (src1Address == null && src2Address == null
				&& memoryReference != null && immediate == null
				&& !option.equals("Store")) {
			if (source1Name.equalsIgnoreCase(destinationName)
					|| source1Name
							.equalsIgnoreCase('[' + destinationName + ']')) {
				this.src1Address = destAddress;
				this.memoryReference = destAddress;
				this.source1 = destAddress;
			} else {
				this.src1Address = "0x"
						+ String.format("%4s", memoryReference).replace(' ',
								'0');
			}

		} else if (src1Address == null && src2Address == null
				&& memoryReference == null && immediate != null
				&& option.equals("Store")) {
			if (source1Name.equalsIgnoreCase(destinationName)
					|| source1Name
							.equalsIgnoreCase('[' + destinationName + ']')) {
				this.src1Address = destAddress;
				this.memoryReference = destAddress;
				this.source1 = destAddress;
			} else {
				this.src1Address = "0x"
						+ String.format("%4s", memoryReference).replace(' ',
								'0');
			}

		}
		}
		else 
		{
			linkAddress = createAddress();
			this.linkAddress = String.format("%4s", linkAddress).replace(' ',
					'0');
		}
	}
	

	private String createAddress() {
		address = "";
		for (int i = 0; i < 4; i++) {
			address += hexNum.charAt(ran.nextInt(hexCount));
		}
		return address;

	}

	private int compute(int num1, int num2) {
		String bin1 = "";
		String bin2 = "";
		String binResult = "";
		if (option.equals("Add")) {
			result = num1 + num2;
		} else if (option.equals("And")) {
			bin1 = Integer.toBinaryString(num1);
			bin2 = Integer.toBinaryString(num2);

			if (bin1.length() >= bin2.length()) {
				bin2 = String.format("%" + bin1.length() + "s", bin2).replace(
						' ', '0');
				for (int i = 0; i < bin1.length(); i++) {
					if (bin1.charAt(i) == '0' || bin2.charAt(i) == '0') {
						binResult += "0";
					} else {
						binResult += "1";
					}

				}
			} else {
				bin1 = String.format("%" + bin2.length() + "s", bin1).replace(
						' ', '0');
				for (int i = 0; i < bin2.length(); i++) {
					if (bin2.charAt(i) == '0' || bin1.charAt(i) == '0') {
						binResult += "0";
					} else {
						binResult += "1";
					}

				}
			}
			result = Integer.parseInt(binResult, 2);
		} else if (option.equals("Load")) {
			result = num1 + num2;
		} else if (option.equals("Store")) {
			result = num1 + num2;
		}
		return result;
	}

	@SuppressWarnings("serial")
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "Next Stage");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}

		@Override
		public void actionPerformed(ActionEvent e) {

			if (count == 1) {
				stageOne();
			} else if (count == 2) {
				stageTwo();
			} else if (count == 3) {
				stageThree();
			} else if (count == 4) {
				stageFour();
			} else if (count == 5) {
				stageFive();
				nextStageButton.setVisible(false);
				resetButton.setVisible(true);
			}
			count++;
		}
	}

	private class NewInstructionListener implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			int choice = JOptionPane
					.showConfirmDialog(
							null,
							"Are you sure you want to enter a new instruction? \n"
									+ "If so, the current DataPathModel window will be closed!",
							"New Instruction Window", JOptionPane.YES_NO_OPTION);
			if (choice == 0) {
				frame.dispose();
				InstructionEntry frame = new InstructionEntry();
				frame.setVisible(true);
			}
		}
	}

	private class ResetListener implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			count = 1;
			addressCLabel.setText("");
			memDataLabel.setText("");
			cSelectLabel.setText("");
			registerCLabel.setText("");
			registerALabel.setText("");
			registerBLabel.setText("");
			registerRALabel.setText("");
			registerRBLabel.setText("");
			rf_WriteLabel.setText("");
			bSelectLabel.setText("");
			immediateLabel.setText("");
			aluInputA.setText("");
			aluInputB.setText("");
			aluOutput.setText("");
			registerRZLabel.setText("");
			registerRMLabel.setText("");
			returnAddressLabel.setText("");
			registerRYLabel.setText("");
			ySelectLabel.setText("");
			addressALabel.setText("");
			addressBLabel.setText("");
			memDataLabel.setText("");
			memAddLabel.setText("");
			resetButton.setVisible(false);
			nextStageButton.setVisible(true);
			stage2HighLabel.setVisible(false);
			stage3HighLabel.setVisible(false);
			stage4HighLabel.setVisible(false);
			stage5HighLabelPart1.setVisible(false);
			stage5HighLabelPart2.setVisible(false);
			addressCLabel.setBackground(Color.WHITE);
			registerCLabel.setBackground(Color.WHITE);
			rf_WriteLabel.setBackground(Color.WHITE);
			registerRYLabel.setBackground(Color.WHITE);
			cSelectLabel.setBackground(Color.WHITE);
			memDataLabel.setBackground(Color.WHITE);
			returnAddressLabel.setBackground(Color.WHITE);
		}
	}
	private ImageIcon resizeImageIcon(ImageIcon icon, int w, int h){
		Image img = icon.getImage();
		Image newimg = img.getScaledInstance(w, h,  java.awt.Image.SCALE_SMOOTH);
		return new ImageIcon(newimg);	
	}
}

@SuppressWarnings("serial")
class HighLight extends JLabel {
	@SuppressWarnings("unused")
	private Graphics g;
	private int width, height;

	public HighLight(int height, int width) {
		this.height = height;
		this.width = width;
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Color c = new Color(0f, 1f, 0f, .2f);
		g.setColor(c);
		g.fillRect(0, 0, height, width);
	}

}