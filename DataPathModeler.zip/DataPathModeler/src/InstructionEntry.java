import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class InstructionEntry extends JFrame{
	private  JFrame frame;
	private  JPanel pan;
	private  JPanel pan2;
	private  GridBagConstraints grid;
	private  JLabel labelsrc1,labelsrc2,labeldest;
	private  JButton submit;
	private  JComboBox<String> instructs;
	protected  String selectedInstruction;
	protected  JTextField src1,src2,dest;
	protected boolean clear= false;
	final static String LABELS = "Labels";
	final static String INS = "Instruction information";
  public void instructionWindow()
  {
	  
	  frame = new JFrame("InstructionEntry");
	  pan = new JPanel();
	  pan2 = new JPanel();
	  String[] instructions = {"ADD","AND","LOAD","STORE","CALL"};
	  instructs = new JComboBox<String>(instructions);
	  instructs.setPreferredSize(new Dimension(143,20));
	  instructs.addActionListener(new InstructionChoice());
	  pan.setLayout(new GridBagLayout());
	  pan2.setLayout(new GridBagLayout());
	  grid = new GridBagConstraints();
	  grid.weightx = 1.0;
	  grid.anchor = GridBagConstraints.NORTHWEST;
	  grid.gridx = 0;
	  grid.gridy = 0;
	  pan.add(new JLabel("Instruction"),grid);
	  grid.weighty = 15;
	  grid.weightx = 1.0;
	  grid.anchor = GridBagConstraints.NORTHWEST;
	  grid.gridx = 0;
	  grid.gridy = 1;
	  pan.add(instructs,grid);
	  frame.add(pan);
	  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	  frame.setLocationRelativeTo(null);
	  frame.pack();
	  frame.setSize(500,200);
	  frame.setResizable(false);
	  frame.setTitle("InstructionSelection");
	  frame.setVisible(true);
  }
  private class InstructionChoice implements ActionListener
  {
	  public void actionPerformed(ActionEvent e) { 
		  JComboBox<String> com = (JComboBox<String>)e.getSource();
		  selectedInstruction = (String)com.getSelectedItem();
		  src1 = new JTextField(8);
		  src2 = new JTextField(8);
		  dest = new JTextField(8);
		  labelsrc1 = new JLabel("Source 1");
		  labelsrc2 = new JLabel("Source 2");
		  labeldest = new JLabel("Destination");
		  submit    = new JButton("Submit");
		if(selectedInstruction.equals("ADD"))
		{
			remove();
			grid.gridx = 1;
            grid.gridy = 1;
			pan.add(dest,grid);
			grid.gridx = 2;
            grid.gridy = 1;
			pan.add(src1,grid);
			grid.gridx = 3;
            grid.gridy = 1;
			pan.add(src2,grid);
			grid.gridx = 1;
            grid.gridy = 0;
            grid.weighty = 0;
			pan.add(labeldest,grid);
			grid.gridx = 2;
            grid.gridy = 0;
            grid.weighty = 0;
			pan.add(labelsrc2,grid);
			grid.gridx = 3;
            grid.gridy = 0;
            grid.weighty = 0;
			pan.add(labelsrc1,grid);
			grid.gridy = 1;
			grid.anchor = GridBagConstraints.LAST_LINE_END;
			pan.add(submit,grid);
			clear = true;
		}
		else if(selectedInstruction.equals("AND"))
		{
			remove();
			grid.gridx = 1;
            grid.gridy = 1;
			pan.add(dest,grid);
			grid.gridx = 2;
            grid.gridy = 1;
			pan.add(src1,grid);
			grid.gridx = 3;
            grid.gridy = 1;
			pan.add(src2,grid);
			grid.gridx = 1;
            grid.gridy = 0;
            grid.weighty = 0;
			pan.add(labeldest,grid);
			grid.gridx = 2;
            grid.gridy = 0;
            grid.weighty = 0;
			pan.add(labelsrc2,grid);
			grid.gridx = 3;
            grid.gridy = 0;
            grid.weighty = 0;
			pan.add(labelsrc1,grid);
			grid.gridy = 1;
			grid.anchor = GridBagConstraints.LAST_LINE_END;
			pan.add(submit,grid);
			clear = true;
		}
		else if(selectedInstruction.equals("LOAD"))
		{
			remove();
			grid.gridx = 1;
            grid.gridy = 1;
			pan.add(dest,grid);
			grid.gridx = 2;
            grid.gridy = 1;
			pan.add(src1,grid);
			grid.gridx = 1;
            grid.gridy = 0;
            grid.weighty = 0;
			pan.add(labeldest,grid);
			grid.gridx = 2;
            grid.gridy = 0;
            grid.weighty = 0;
			pan.add(labelsrc1,grid);
			grid.gridy = 1;
			grid.anchor = GridBagConstraints.LAST_LINE_END;
			pan.add(submit,grid);
			clear = true;
		}
		else if(selectedInstruction.equals("STORE"))
		{
			remove();
			grid.gridx = 1;
            grid.gridy = 1;
			pan.add(dest,grid);
			grid.gridx = 2;
            grid.gridy = 1;
			pan.add(src1,grid);
			grid.gridx = 1;
            grid.gridy = 0;
            grid.weighty = 0;
			pan.add(labeldest,grid);
			grid.gridx = 2;
            grid.gridy = 0;
            grid.weighty = 0;
			pan.add(labelsrc1,grid);
			grid.gridy = 1;
			grid.anchor = GridBagConstraints.LAST_LINE_END;
			pan.add(submit,grid);
			clear = true;
		}
		else if(selectedInstruction.equals("CALL"))
		{
			remove();
			grid.gridx = 1;
            grid.gridy = 1;
			pan.add(dest,grid);
			grid.gridx = 2;
            grid.gridy = 0;
            grid.weighty = 0;
			pan.add(labeldest,grid);
			grid.gridy = 1;
			grid.anchor = GridBagConstraints.LAST_LINE_END;
			pan.add(submit,grid);
			clear = true;
		}
		pan.revalidate();
		validate();
	  } 
	private void remove()
	{
		if(clear == true)
		{
			try{
			    pan.remove(src1);
				pan.remove(src2);
				pan.remove(dest);
				pan.remove(labelsrc1);
				pan.remove(labelsrc2);
				pan.remove(labeldest);
				pan.remove(submit);
				pan.revalidate();
				validate();
				pan.repaint();
				}catch(Exception o){}
		}
	}
	  
  }
  

  public static void main(String args[])
  {
	  InstructionEntry e = new InstructionEntry();
	  e.instructionWindow();
  }
}