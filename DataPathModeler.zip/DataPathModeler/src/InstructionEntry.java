import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.Random;

import javax.swing.*;

public class InstructionEntry extends JFrame{
	//public static InstructionEntry e = new InstructionEntry();
	private  JFrame frame;
	private  JPanel pan;
	private  GridBagConstraints grid;
	private  JLabel labelsrc1;
	private  JLabel labelsrc2;
	private  JLabel labeldest;
	private  JButton submit;
	private  JComboBox<String> instructs;
	private  JComboBox<String> com;
	protected  String selectedInstruction;
	protected  JTextField src1;
	protected  JTextField src2;
	protected  JTextField dest;
	protected Random rand;
	protected boolean clear;
	protected int immediate,memoryReference;
	protected String source1,source2,destination;
	public InstructionEntry()
	  {
		 labelsrc1 = new JLabel("Source 1");
		 labelsrc2 = new JLabel("Source 2");
		 labeldest = new JLabel("Destination");
		 submit = new JButton("Submit");
		 src1 = new JTextField(8);
		 src2 = new JTextField(8);
		 dest = new JTextField(8);
		 rand = new Random();
		 clear= false;
	  }
  public InstructionEntry(String h)
  {
	  
  }
  public void instructionWindow()
  {
	  
	  frame = new JFrame("InstructionEntry");
	  pan = new JPanel();
	  String[] instructions = {"-select-","ADD","AND","LOAD","STORE","CALL"};
	  instructs = new JComboBox<String>(instructions);
	  instructs.setPreferredSize(new Dimension(143,20));
	  instructs.addActionListener(new InstructionChoice());
	  submit.addActionListener(new SubmitListener());
	  pan.setLayout(new GridBagLayout());
	  grid = new GridBagConstraints();
	  //grid.weightx = 1.0;
	  grid.anchor = GridBagConstraints.NORTHWEST;
	  grid.gridx = 0;
	  grid.gridy = 0;
	  pan.add(new JLabel("Instruction"),grid);
	  grid.weighty = 15;
	  grid.weightx = 1.0;
	  grid.anchor = GridBagConstraints.NORTHWEST;
	  grid.gridx = 0;
	  grid.gridy = 1;
	  pan.add(instructs,grid);
	  frame.add(pan);
	  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	  frame.setLocationRelativeTo(null);
	  frame.pack();
	  frame.setSize(500,200);
	  frame.setResizable(false);
	  frame.setTitle("InstructionSelection");
	  frame.setVisible(true);
  }
  private class InstructionChoice implements ActionListener
  {
	  public void actionPerformed(ActionEvent e) { 
		  com = (JComboBox<String>)e.getSource();
		  selectedInstruction = (String)com.getSelectedItem();
		  if(selectedInstruction.equals("-select-")){
			  remove();
		  }
		  else if(selectedInstruction.equals("ADD"))
		{
			remove();
			grid.gridx = 1;
            grid.gridy = 1;
            grid.weighty = 1;
            grid.anchor = GridBagConstraints.FIRST_LINE_START;
			pan.add(dest,grid);
			grid.gridx = 2;
            grid.gridy = 1;
            grid.weighty = 1;
			pan.add(src1,grid);
			grid.gridx = 3;
            grid.gridy = 1;
            grid.weighty = 1;
			pan.add(src2,grid);
			grid.gridx = 1;
            grid.gridy = 0;
            grid.weighty = 0;
			pan.add(labeldest,grid);
			grid.gridx = 2;
            grid.gridy = 0;
            grid.weighty = 0;
			pan.add(labelsrc1,grid);
			grid.gridx = 3;
            grid.gridy = 0;
            grid.weighty = 0;
			pan.add(labelsrc2,grid);
			grid.gridy = 1;
			grid.anchor = GridBagConstraints.LAST_LINE_END;
			pan.add(submit,grid);
			clear = true;
		}
		else if(selectedInstruction.equals("AND"))
		{
			remove();
			grid.gridx = 1;
            grid.gridy = 1;
            grid.anchor = GridBagConstraints.FIRST_LINE_START;
			pan.add(dest,grid);
			grid.gridx = 2;
            grid.gridy = 1;
			pan.add(src1,grid);
			grid.gridx = 3;
            grid.gridy = 1;
			pan.add(src2,grid);
			grid.gridx = 1;
            grid.gridy = 0;
            grid.weighty = 0;
			pan.add(labeldest,grid);
			grid.gridx = 2;
            grid.gridy = 0;
            grid.weighty = 0;
			pan.add(labelsrc1,grid);
			grid.gridx = 3;
            grid.gridy = 0;
            grid.weighty = 0;
			pan.add(labelsrc2,grid);
			grid.gridy = 1;
			grid.anchor = GridBagConstraints.LAST_LINE_END;
			pan.add(submit,grid);
			clear = true;
		}
		else if(selectedInstruction.equals("LOAD"))
		{
			remove();
			grid.gridx = 1;
            grid.gridy = 1;
            grid.weightx = 5;
            grid.anchor = GridBagConstraints.FIRST_LINE_START;
			pan.add(dest,grid);
			grid.gridx = 2;
            grid.gridy = 1;
            grid.weightx = 10;
			pan.add(src1,grid);
			grid.gridx = 1;
            grid.gridy = 0;
            grid.weighty = 0;
			pan.add(labeldest,grid);
			grid.gridx = 2;
            grid.gridy = 0;
            grid.weighty = 0;
			pan.add(labelsrc1,grid);
			grid.gridy = 1;
			grid.anchor = GridBagConstraints.LAST_LINE_END;
			pan.add(submit,grid);
			clear = true;
		}
		else if(selectedInstruction.equals("STORE"))
		{
			remove();
			grid.gridx = 1;
            grid.gridy = 1;
            grid.anchor = GridBagConstraints.FIRST_LINE_START;
			pan.add(dest,grid);
			grid.gridx = 2;
            grid.gridy = 1;
			pan.add(src1,grid);
			grid.gridx = 1;
            grid.gridy = 0;
            grid.weighty = 0;
			pan.add(labeldest,grid);
			grid.gridx = 2;
            grid.gridy = 0;
            grid.weighty = 0;
			pan.add(labelsrc1,grid);
			grid.gridy = 1;
			grid.anchor = GridBagConstraints.LAST_LINE_END;
			pan.add(submit,grid);
			clear = true;
		}
		else if(selectedInstruction.equals("CALL"))
		{
			remove();
			grid.gridx = 1;
            grid.gridy = 1;
            grid.anchor = GridBagConstraints.FIRST_LINE_START;
			pan.add(dest,grid);
			grid.gridx = 1;
            grid.gridy = 0;
            grid.weighty = 0;
            grid.weightx = 5;
			pan.add(labeldest,grid);
			grid.gridy = 1;
			grid.anchor = GridBagConstraints.LAST_LINE_END;
			pan.add(submit,grid);
			clear = true;
		}
		pan.revalidate();
		validate();
		pan.repaint();
	  } 
	private void remove()
	{
		if(clear == true)
		{
			try{
				    pan.remove(src1);
					pan.remove(src2);
					pan.remove(dest);
					pan.remove(labelsrc1);
					pan.remove(labelsrc2);
					pan.remove(labeldest);
					pan.remove(submit);
					clear = false;
				}
			catch(Exception o)
			{}
		}
	}
	
  }
  
  private class SubmitListener implements ActionListener
	{
	  public void actionPerformed(ActionEvent e) {
		  
	      if(selectedInstruction.equals("ADD"))
		  {
			 if(isNumeric(dest.getText()))
		     {
			     alert("The Destination cannot be an immediate value!");
			 }
			 else if(isAddress(src1.getText()) && isAddress(src2.getText()))
			 {
				 alert("Cannot do a memory to memory ADD!");
			 }
			 if(isNumeric(src1.getText()) && !isNumeric(src2.getText()))
			 {
				 immediate = Integer.parseInt(src1.getText());
				 source2 = src2.getText();
				 destination = dest.getText();
				 new DataPathModel();
				 close();
			 }
			 else if((!isNumeric(src1.getText()) && isNumeric(src2.getText())))
			 {
				 source1 = src1.getText();
				 //setSource1(source1);
				 //System.out.println(source1);
				 immediate = Integer.parseInt(src2.getText());
				 destination = dest.getText();
				 new DataPathModel(source1);
				 close();
			 }
			 else if((!isNumeric(src1.getText()) && !isNumeric(src2.getText())))
			 {
				 source1 = src1.getText();
				 source2 = src2.getText();
				 destination = dest.getText();
				 new DataPathModel();
				 close();
			 }
			 else
			 {
				 alert("Cannot ADD 2 Immediate Values!");
			 }
		  }
		  else  if(selectedInstruction.equals("AND"))
		  {
			  
			     if(isNumeric(dest.getText()))
				 {
					 alert("The Destination cannot be an immediate value!");
				 }
				 else if(isAddress(src1.getText()) && isAddress(src2.getText()))
				 {
					 alert("Cannot do a memory to memory AND!");
				 }
			     else if(isNumeric(src1.getText()) && !isNumeric(src2.getText()))
				 {
					 immediate = Integer.parseInt(src1.getText());
					 source2 = src2.getText();
					 destination = dest.getText();
					 new DataPathModel();
					 close();
				 }
				 else if((!isNumeric(src1.getText()) && isNumeric(src2.getText())))
				 {
					 source1 = src1.getText();
					 //System.out.println(source1);
					 immediate = Integer.parseInt(src2.getText());
					 destination = dest.getText();
					 new DataPathModel();
					 close();
				 }
				 else if((!isNumeric(src1.getText()) && !isNumeric(src2.getText())))
				 {
					 source1 = src1.getText();
					 source2 = src2.getText();
					 destination = dest.getText();
					 new DataPathModel();
					 close();
				 }
				 
				 else
				 {
					 alert("Cannot AND 2 Immediate Values!");
				 }
		  }
		  else  if(selectedInstruction.equals("LOAD"))
		  {
			  if(isNumeric(dest.getText()))
			   {
					 alert("The Destination cannot be an immediate value!");
			   }
			  else if(isNumeric(src1.getText()))
			  {
			    immediate = Integer.parseInt(src1.getText());
			    destination = dest.getText();
			    new DataPathModel();
			    close();
			  }
			  else if(isAddress(src1.getText()))
			  {
				  memoryReference = rand.nextInt(9999) + 1;
				  destination = dest.getText();
				  new DataPathModel();
				  close();
			  }
		  }
		  else  if(selectedInstruction.equals("STORE"))
		  {
			  if(isNumeric(dest.getText()))
			  {
					 alert("The Destination cannot be an immediate value!");
			  }
			  else if(isAddress(src1.getText()))
			  {
				  memoryReference = rand.nextInt(9999) + 1;
				  new DataPathModel();
				  close();
			  }
			 source1 = src1.getText();
			 destination = dest.getText();
			 new DataPathModel();
			 close();
		  }
		  else  if(selectedInstruction.equals("CALL"))
		  {
			  if(isNumeric(dest.getText()))
			  {
					 alert("The Destination cannot be an immediate value!");
			  }
			  else if(isAddress(src1.getText()))
			  {
				  memoryReference = rand.nextInt(9999) + 1;
				  new DataPathModel();
				  close();
			  }
			  else
			  {
				 destination = dest.getText(); 
				 new DataPathModel();
				 close();
			  }
			  
		  }
	  }
	}
  public void close() {
	  frame.dispose();
  }
public boolean isNumeric(String source)
{
	try
	{
		int d = Integer.parseInt(source);
	}
	catch(NumberFormatException e)
	{
		return false;
	}
	return true;
}

public boolean isAddress(String source)
{
	boolean validReference = false;
	char test;
	if(source.length() <= 1)
	{
		validReference = false;
	}
	else if(source.charAt(0) == '[' && source.charAt(source.length()-1) == ']')
	{
		for(int i = 1; i < source.length()-1; i++)
		{
			test = source.charAt(i);
			if(Character.isLetterOrDigit(test))
			{
				validReference = true;
			}
			else
			{
				validReference = false;
				alert("Invalid character inside memeory reference!");
				break;
			}
		}
		
	}
	else if(source.charAt(0) == '[' && source.charAt(source.length()-1) != ']')
	{
		alert("Missing ] for source register or invalid entry after memory reference!");
	}
	else if(source.charAt(0) != '[' && source.charAt(source.length()-1) == ']')
	{
		alert("Missing [ for source register or invalid entry after memory reference!");
	}
	/*for(int i = 0; i < source.length(); i++)
	{
		if(source.charAt(i) == '[')
		{
			
		}
	}*/
	return validReference;
}
public int getImmediate()
{
	return immediate;
}
public int getMemoryReference()
{
	return memoryReference;
}
public String getSource1()
{
	//System.out.println(source1);
	return source1;
}
public String getSource2()
{
	return source2;
}
public String destination()
{
	return destination;
}
private void setSource1(String source1)
{
	this.source1 = source1;
}
public void alert(String message)
{
	JOptionPane.showMessageDialog(frame, message, "Invalid Instruction", JOptionPane.ERROR_MESSAGE);
}
  public static void main(String args[])
  {
	  InstructionEntry e = new InstructionEntry();
	  e.instructionWindow();
  }
 /* public static InstructionEntry getClass(){
	  return e;
	  
  }*/
}