import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLayeredPane;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.JTextField;


public class DataPathModel{
	private JFrame frame;
	private JTextField textField;
	private String source1;

	public DataPathModel() {
		initialize();
	}
	public DataPathModel(String source1) {
		this.source1 = source1;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 695, 1010);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JLayeredPane layeredPane = new JLayeredPane();
		GroupLayout groupLayout = new GroupLayout(frame.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addComponent(layeredPane, GroupLayout.DEFAULT_SIZE, 695, Short.MAX_VALUE)
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addComponent(layeredPane, GroupLayout.DEFAULT_SIZE, 1010, Short.MAX_VALUE)
		);
		
		JLabel lblNewLabel_1 = new JLabel(source1);
		lblNewLabel_1.setBackground(Color.WHITE);
		lblNewLabel_1.setBounds(150, 141, 99, 17);
		layeredPane.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setEditable(false);
		textField.setForeground(Color.WHITE);
		textField.setBackground(Color.WHITE);
		textField.setBounds(150, 138, 99, 20);
		textField.setBorder(null);
		layeredPane.add(textField);
		textField.setColumns(10);
		
		InstructionEntry e = new InstructionEntry("i");
		JLabel lblNewLabel = new JLabel();
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Splash\\Downloads\\Datapath.jpg"));
		lblNewLabel.setBounds(0, 0, 687, 983);
		lblNewLabel.setOpaque(true);
		layeredPane.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(150, 83, 99, 24);
		layeredPane.add(panel);
		frame.getContentPane().setLayout(groupLayout);
		frame.setVisible(true);
	}
}
